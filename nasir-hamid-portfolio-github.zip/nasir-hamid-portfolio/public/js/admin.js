/* Admin dashboard logic — vanilla JS, talks to /api/admin */
(function () {
  "use strict";

  const ICONS = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
    code: '<path d="m8 8-5 4 5 4M16 8l5 4-5 4M14 4l-4 16"/>',
    file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z"/><path d="M14 3v5h5"/>',
    play: '<path d="M8 5.5v13l11-6.5Z"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m4 7 8 6 8-6"/>',
    edit: '<path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/><path d="m14 6 4 4"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6Z"/>',
    external: '<path d="M14 4h6v6M20 4 11 13M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4"/>',
    logout: '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 8l-4 4 4 4M6 12h9"/>',
  };

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = (v = "") =>
    String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const svgIcon = (name) =>
    `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ""}</svg>`;

  $$("[data-icon]").forEach((el) => (el.innerHTML = svgIcon(el.dataset.icon)));

  const state = { projects: [], resources: [], videos: [], messages: [], content: null, stats: null };

  /* ------------------------------------------------------------------ toast */
  let toastTimer;
  function toast(message, isError) {
    const el = $("#toast");
    el.textContent = message;
    el.className = `toast is-on${isError ? " is-error" : ""}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (el.className = "toast"), 3200);
  }

  /* -------------------------------------------------------------------- API */
  async function api(path, options = {}) {
    const headers = { "x-requested-with": "fetch", ...(options.headers || {}) };
    let body = options.body;
    if (body && !(body instanceof FormData)) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(body);
    }
    const res = await fetch(path, {
      method: options.method || "GET",
      headers,
      body,
      credentials: "same-origin",
    });
    if (res.status === 401) {
      showLogin();
      throw new Error("Session expired. Please sign in again.");
    }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data;
  }

  /* ------------------------------------------------------------- auth views */
  function showLogin() {
    $("#appView").hidden = true;
    $("#loginView").hidden = false;
  }

  async function showApp(admin) {
    $("#loginView").hidden = true;
    $("#appView").hidden = false;
    $("#adminEmail").textContent = admin?.email || "admin";
    await refreshAll();
  }

  $("#loginForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const form = e.target;
    const errorEl = $("#loginError");
    const btn = $("button[type=submit]", form);
    errorEl.textContent = "";
    btn.disabled = true;
    try {
      const data = await api("/api/admin/login", {
        method: "POST",
        body: { email: form.email.value, password: form.password.value },
      });
      form.reset();
      showApp(data.admin);
    } catch (err) {
      errorEl.textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });

  $("#logoutBtn").addEventListener("click", async () => {
    try {
      await api("/api/admin/logout", { method: "POST" });
    } catch {}
    showLogin();
  });

  /* ------------------------------------------------------------------- tabs */
  function activate(tab) {
    $$("[data-panel]").forEach((p) => (p.hidden = p.dataset.panel !== tab));
    $$("#sidebarNav button").forEach((b) => b.classList.toggle("is-active", b.dataset.tab === tab));
    window.scrollTo({ top: 0 });
  }

  $("#sidebarNav").addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-tab]");
    if (btn) activate(btn.dataset.tab);
  });

  document.addEventListener("click", (e) => {
    const jump = e.target.closest("[data-tab-jump]");
    if (jump) activate(jump.dataset.tabJump);
    const quick = e.target.closest("[data-quick]");
    if (quick) openEditor(quick.dataset.quick);
  });

  /* ----------------------------------------------------------------- loading */
  async function refreshAll() {
    try {
      const [stats, projects, resources, videos, messages, content] = await Promise.all([
        api("/api/admin/stats"),
        api("/api/admin/projects"),
        api("/api/admin/resources"),
        api("/api/admin/videos"),
        api("/api/admin/messages"),
        api("/api/admin/content"),
      ]);
      Object.assign(state, { stats, projects, resources, videos, messages, content });
      renderStats();
      renderRecent();
      renderProjects();
      renderResources();
      renderVideos();
      renderMessages();
      fillContentForms();
      $("#badgeResources").textContent = resources.length;
      $("#badgeMessages").textContent = messages.filter((m) => !m.is_read).length;
      $("#badgeMessages").hidden = messages.filter((m) => !m.is_read).length === 0;
    } catch (err) {
      toast(err.message, true);
    }
  }

  const fmtSize = (b) => {
    if (!b) return "0 KB";
    const u = ["B", "KB", "MB", "GB"];
    let i = 0;
    let n = b;
    while (n >= 1024 && i < u.length - 1) {
      n /= 1024;
      i += 1;
    }
    return `${n >= 10 || i === 0 ? Math.round(n) : n.toFixed(1)} ${u[i]}`;
  };

  const fmtDate = (iso) => {
    if (!iso) return "";
    const d = new Date(iso.includes("T") ? iso : iso.replace(" ", "T") + "Z");
    return Number.isNaN(d.getTime())
      ? iso
      : d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
  };

  /* --------------------------------------------------------------- rendering */
  function renderStats() {
    const s = state.stats;
    if (!s) return;
    $("#statsGrid").innerHTML = `
      <div class="stat stat--mint"><p class="stat__label">Downloads</p><p class="stat__value">${s.downloads}</p><p class="stat__sub">across ${s.resources} resource${s.resources === 1 ? "" : "s"}</p></div>
      <div class="stat"><p class="stat__label">Projects</p><p class="stat__value">${s.projects}</p><p class="stat__sub">${s.projectsPublished} published</p></div>
      <div class="stat"><p class="stat__label">Resources</p><p class="stat__value">${s.resources}</p><p class="stat__sub">${s.resourcesPublished} published · ${fmtSize(s.storage)} stored</p></div>
      <div class="stat"><p class="stat__label">Videos</p><p class="stat__value">${s.videos}</p><p class="stat__sub">${s.videosPublished} published</p></div>
      <div class="stat"><p class="stat__label">Messages</p><p class="stat__value">${s.messages}</p><p class="stat__sub">${s.unread} unread</p></div>`;
  }

  function renderRecent() {
    const items = [...state.messages.slice(0, 3).map((m) => ({ type: "Message", title: m.name, date: m.created_at })),
      ...state.resources.slice(0, 2).map((r) => ({ type: "Resource", title: r.title, date: r.created_at })),
      ...state.projects.slice(0, 2).map((p) => ({ type: "Project", title: p.title, date: p.created_at }))]
      .sort((a, b) => String(b.date).localeCompare(String(a.date)))
      .slice(0, 6);
    $("#recentList").innerHTML = items.length
      ? items
          .map(
            (i) => `<div class="row"><div class="row__main"><p class="row__title">${esc(i.title)}</p>
            <p class="row__meta">${i.type} · ${fmtDate(i.date)}</p></div></div>`
          )
          .join("")
      : `<p class="empty-state">Nothing yet — upload your first resource or project.</p>`;
  }

  function renderProjects() {
    $("#projectsList").innerHTML = state.projects.length
      ? state.projects
          .map(
            (p) => `<div class="row">
        ${p.thumb ? `<img class="row__thumb" src="${esc(p.thumb)}" alt="">` : `<span class="row__thumb">IMG</span>`}
        <div class="row__main">
          <p class="row__title">${esc(p.title)}
            <span class="pill ${p.published ? "pill--live" : "pill--draft"}">${p.published ? "Live" : "Draft"}</span>
            ${p.featured ? '<span class="pill">Featured</span>' : ""}</p>
          <p class="row__meta">${esc(p.summary || "No summary")} · ${fmtDate(p.created_at)}</p>
        </div>
        <div class="row__actions">
          <a class="btn btn--ghost btn--sm" href="/projects/${esc(p.slug)}" target="_blank" rel="noopener">View</a>
          <button class="btn btn--ghost btn--sm" data-edit-project="${p.id}">Edit</button>
          <button class="btn btn--ghost btn--sm" data-toggle-project="${p.id}">${p.published ? "Unpublish" : "Publish"}</button>
          <button class="btn btn--danger btn--sm" data-delete-project="${p.id}">Delete</button>
        </div>
      </div>`
          )
          .join("")
      : `<p class="empty-state">No projects yet. Click “New project”.</p>`;
  }

  function renderResources() {
    $("#resourcesList").innerHTML = state.resources.length
      ? state.resources
          .map(
            (r) => `<div class="row">
        ${r.thumb ? `<img class="row__thumb" src="${esc(r.thumb)}" alt="">` : `<span class="row__thumb">PDF</span>`}
        <div class="row__main">
          <p class="row__title">${esc(r.title)}
            <span class="pill ${r.published ? "pill--live" : "pill--draft"}">${r.published ? "Live" : "Draft"}</span></p>
          <p class="row__meta">${esc(r.category)} · ${fmtSize(r.file_size)} · ${r.downloads} downloads · ${fmtDate(r.created_at)}</p>
        </div>
        <div class="row__actions">
          <a class="btn btn--ghost btn--sm" href="/resources/${esc(r.slug)}" target="_blank" rel="noopener">View</a>
          <button class="btn btn--ghost btn--sm" data-edit-resource="${r.id}">Edit</button>
          <button class="btn btn--ghost btn--sm" data-toggle-resource="${r.id}">${r.published ? "Unpublish" : "Publish"}</button>
          <button class="btn btn--danger btn--sm" data-delete-resource="${r.id}">Delete</button>
        </div>
      </div>`
          )
          .join("")
      : `<p class="empty-state">No resources yet. Upload your first PDF.</p>`;
  }

  function renderVideos() {
    $("#videosList").innerHTML = state.videos.length
      ? state.videos
          .map(
            (v) => `<div class="row">
        ${v.thumb ? `<img class="row__thumb" src="${esc(v.thumb)}" alt="">` : `<span class="row__thumb">VID</span>`}
        <div class="row__main">
          <p class="row__title">${esc(v.title)}
            <span class="pill ${v.published ? "pill--live" : "pill--draft"}">${v.published ? "Live" : "Draft"}</span></p>
          <p class="row__meta">${esc(v.category)}${v.youtube_id ? " · YouTube" : " · External"}${v.duration ? ` · ${esc(v.duration)}` : ""} · ${fmtDate(v.created_at)}</p>
        </div>
        <div class="row__actions">
          <a class="btn btn--ghost btn--sm" href="/videos/${esc(v.slug)}" target="_blank" rel="noopener">View</a>
          <button class="btn btn--ghost btn--sm" data-edit-video="${v.id}">Edit</button>
          <button class="btn btn--ghost btn--sm" data-toggle-video="${v.id}">${v.published ? "Unpublish" : "Publish"}</button>
          <button class="btn btn--danger btn--sm" data-delete-video="${v.id}">Delete</button>
        </div>
      </div>`
          )
          .join("")
      : `<p class="empty-state">No videos yet. Paste a YouTube link to add one.</p>`;
  }

  function renderMessages() {
    const list = state.messages;
    $("#messagesHint").textContent = list.length
      ? `${list.filter((m) => !m.is_read).length} unread of ${list.length}`
      : "";
    $("#messagesList").innerHTML = list.length
      ? list
          .map(
            (m) => `<article class="message-card ${m.is_read ? "" : "is-unread"}">
        <div class="message-card__head">
          <div>
            <p class="row__title">${esc(m.name)} ${m.is_read ? "" : '<span class="pill pill--unread">New</span>'}</p>
            <p class="row__meta">${esc(m.email)} · ${fmtDate(m.created_at)}${m.subject ? ` · ${esc(m.subject)}` : ""}</p>
          </div>
          <div class="row__actions">
            <a class="btn btn--ghost btn--sm" href="mailto:${esc(m.email)}?subject=Re: ${encodeURIComponent(m.subject || "Your message")}">Reply</a>
            <button class="btn btn--ghost btn--sm" data-read-message="${m.id}" data-read="${m.is_read ? 0 : 1}">${m.is_read ? "Mark unread" : "Mark read"}</button>
            <button class="btn btn--danger btn--sm" data-delete-message="${m.id}">Delete</button>
          </div>
        </div>
        <p class="message-card__body">${esc(m.message)}</p>
      </article>`
          )
          .join("")
      : `<p class="empty-state">No messages yet.</p>`;
  }

  /* ---------------------------------------------------------- editor modal */
  const modal = $("#modal");
  const modalForm = $("#modalForm");

  const CATEGORIES = ["Documents", "Notes", "Presentations", "Guides", "Books"];
  const VIDEO_CATEGORIES = ["My videos", "Recommended watching", "Tutorials", "Playlists", "Study sessions"];

  function closeModal() {
    if (modal.open) modal.close();
    modalForm.innerHTML = "";
  }

  $("#modalClose").addEventListener("click", closeModal);
  modal.addEventListener("cancel", (e) => {
    e.preventDefault();
    closeModal();
  });
  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeModal();
  });

  function openModal(title, sub) {
    $("#modalTitle").textContent = title;
    $("#modalSub").textContent = sub || "";
    if (!modal.open) modal.showModal();
  }

  function openEditor(type, record = null) {
    modalForm.reset();
    const editing = Boolean(record);
    const fileHint = editing ? "Leave empty to keep the current file" : "Required";

    if (type === "project") {
      openModal(editing ? "Edit project" : "New project", "Add a project to your public gallery.");
      modalForm.innerHTML = `
        <div class="form-grid">
          <label class="field field--wide"><span>Title</span><input name="title" required value="${esc(record?.title || "")}"></label>
          <label class="field field--wide"><span>Short summary (shown on the card)</span><textarea name="summary" rows="2">${esc(record?.summary || "")}</textarea></label>
          <label class="field field--wide"><span>Full description</span><textarea name="description" rows="5">${esc(record?.description || "")}</textarea></label>
          <label class="field"><span>Technologies (comma separated)</span><input name="tech" value="${esc((record?.tech || []).join(', '))}" placeholder="HTML, CSS, JavaScript"></label>
          <label class="field"><span>Live project URL</span><input name="live_url" type="url" value="${esc(record?.live_url || "")}" placeholder="https://…"></label>
          <label class="field"><span>Source code URL (optional)</span><input name="repo_url" type="url" value="${esc(record?.repo_url || "")}" placeholder="https://github.com/…"></label>
          <label class="field"><span>Preview image (JPG/PNG/WebP, max 5 MB)</span><input name="thumb" type="file" accept="image/jpeg,image/png,image/webp"><small>${fileHint}</small></label>
          <label class="field switch"><input type="checkbox" name="featured" ${record?.featured ? "checked" : ""}> Feature on homepage</label>
          <label class="field switch"><input type="checkbox" name="published" ${!record || record.published ? "checked" : ""}> Published</label>
        </div>
        <div class="form-actions">
          <button class="btn btn--primary" type="submit">${editing ? "Save changes" : "Create project"}</button>
          <button class="btn btn--ghost" type="button" data-close>Cancel</button>
          <span class="form-message" role="status"></span>
        </div>`;
      modalForm.onsubmit = (e) => {
        e.preventDefault();
        submitEntity("projects", record?.id, () => {
          const fd = new FormData(modalForm);
          fd.set("featured", modalForm.featured.checked ? "1" : "0");
          fd.set("published", modalForm.published.checked ? "1" : "0");
          fd.set("tech", modalForm.tech.value);
          return fd;
        });
      };
    }

    if (type === "resource") {
      openModal(editing ? "Edit resource" : "Upload a resource", "PDF only · maximum 25 MB.");
      modalForm.innerHTML = `
        <div class="form-grid">
          <label class="field field--wide"><span>Title</span><input name="title" required value="${esc(record?.title || "")}"></label>
          <label class="field"><span>Category</span>
            <select name="category">${CATEGORIES.map((c) => `<option ${record?.category === c ? "selected" : ""}>${c}</option>`).join("")}</select>
          </label>
          <label class="field"><span>PDF file</span><input name="file" type="file" accept="application/pdf" ${editing ? "" : "required"}><small>${fileHint}</small></label>
          <label class="field field--wide"><span>Description</span><textarea name="description" rows="3">${esc(record?.description || "")}</textarea></label>
          <label class="field"><span>Thumbnail (optional, JPG/PNG/WebP)</span><input name="thumb" type="file" accept="image/jpeg,image/png,image/webp"></label>
          <label class="field switch"><input type="checkbox" name="published" ${!record || record.published ? "checked" : ""}> Published</label>
        </div>
        <div class="form-actions">
          <button class="btn btn--primary" type="submit">${editing ? "Save changes" : "Upload resource"}</button>
          <button class="btn btn--ghost" type="button" data-close>Cancel</button>
          <span class="form-message" role="status"></span>
        </div>`;
      modalForm.onsubmit = (e) => {
        e.preventDefault();
        submitEntity("resources", record?.id, () => {
          const fd = new FormData(modalForm);
          fd.set("published", modalForm.published.checked ? "1" : "0");
          return fd;
        });
      };
    }

    if (type === "video") {
      openModal(editing ? "Edit video" : "Add a video", "Paste a YouTube link — the thumbnail is fetched automatically.");
      modalForm.innerHTML = `
        <div class="form-grid">
          <label class="field field--wide"><span>Title</span><input name="title" required value="${esc(record?.title || "")}"></label>
          <label class="field"><span>Category / playlist</span>
            <select name="category">${VIDEO_CATEGORIES.map((c) => `<option ${record?.category === c ? "selected" : ""}>${c}</option>`).join("")}</select>
          </label>
          <label class="field"><span>Duration (optional)</span><input name="duration" value="${esc(record?.duration || "")}" placeholder="12:04"></label>
          <label class="field field--wide"><span>YouTube link or ID</span><input name="youtube" value="${esc(record?.youtube_id || "")}" placeholder="https://www.youtube.com/watch?v=…"><small>Leave empty if the video is hosted elsewhere.</small></label>
          <label class="field field--wide"><span>External video URL (optional)</span><input name="external_url" type="url" value="${esc(record?.external_url || "")}" placeholder="https://…"></label>
          <label class="field field--wide"><span>Description</span><textarea name="description" rows="3">${esc(record?.description || "")}</textarea></label>
          <label class="field"><span>Custom thumbnail (optional)</span><input name="thumb" type="file" accept="image/jpeg,image/png,image/webp"></label>
          <label class="field switch"><input type="checkbox" name="published" ${!record || record.published ? "checked" : ""}> Published</label>
        </div>
        <div class="form-actions">
          <button class="btn btn--primary" type="submit">${editing ? "Save changes" : "Add video"}</button>
          <button class="btn btn--ghost" type="button" data-close>Cancel</button>
          <span class="form-message" role="status"></span>
        </div>`;
      modalForm.onsubmit = (e) => {
        e.preventDefault();
        submitEntity("videos", record?.id, () => {
          const fd = new FormData(modalForm);
          fd.set("published", modalForm.published.checked ? "1" : "0");
          return fd;
        });
      };
    }

    modalForm.addEventListener("click", (e) => {
      if (e.target.closest("[data-close]")) closeModal();
    });
  }

  async function submitEntity(entity, id, buildBody) {
    const msg = $(".form-message", modalForm);
    const submitBtn = $("button[type=submit]", modalForm);
    msg.textContent = "";
    msg.className = "form-message";
    submitBtn.disabled = true;
    const original = submitBtn.textContent;
    submitBtn.textContent = "Saving…";
    try {
      await api(`/api/admin/${entity}${id ? `/${id}` : ""}`, {
        method: id ? "PUT" : "POST",
        body: buildBody(),
      });
      closeModal();
      toast(id ? "Changes saved." : "Published.");
      await refreshAll();
    } catch (err) {
      msg.textContent = err.message;
      msg.className = "form-message is-error";
      submitBtn.disabled = false;
      submitBtn.textContent = original;
    }
  }

  /* ------------------------------------------------------- row action routing */
  document.addEventListener("click", async (e) => {
    const btn = e.target.closest("button");
    if (!btn) return;
    const d = btn.dataset;

    try {
      if (d.editProject) openEditor("project", state.projects.find((p) => p.id == d.editProject));
      if (d.editResource) openEditor("resource", state.resources.find((r) => r.id == d.editResource));
      if (d.editVideo) openEditor("video", state.videos.find((v) => v.id == d.editVideo));

      if (d.toggleProject) {
        const item = state.projects.find((p) => p.id == d.toggleProject);
        await api(`/api/admin/projects/${item.id}`, { method: "PUT", body: { published: item.published ? "0" : "1" } });
        toast(item.published ? "Project unpublished." : "Project published.");
        await refreshAll();
      }
      if (d.toggleResource) {
        const item = state.resources.find((r) => r.id == d.toggleResource);
        await api(`/api/admin/resources/${item.id}`, { method: "PUT", body: { published: item.published ? "0" : "1" } });
        toast(item.published ? "Resource unpublished." : "Resource published.");
        await refreshAll();
      }
      if (d.toggleVideo) {
        const item = state.videos.find((v) => v.id == d.toggleVideo);
        await api(`/api/admin/videos/${item.id}`, { method: "PUT", body: { published: item.published ? "0" : "1" } });
        toast(item.published ? "Video unpublished." : "Video published.");
        await refreshAll();
      }

      if (d.deleteProject && confirm("Delete this project permanently?")) {
        await api(`/api/admin/projects/${d.deleteProject}`, { method: "DELETE" });
        toast("Project deleted.");
        await refreshAll();
      }
      if (d.deleteResource && confirm("Delete this resource and its PDF file permanently?")) {
        await api(`/api/admin/resources/${d.deleteResource}`, { method: "DELETE" });
        toast("Resource deleted.");
        await refreshAll();
      }
      if (d.deleteVideo && confirm("Delete this video?")) {
        await api(`/api/admin/videos/${d.deleteVideo}`, { method: "DELETE" });
        toast("Video deleted.");
        await refreshAll();
      }
      if (d.deleteMessage && confirm("Delete this message?")) {
        await api(`/api/admin/messages/${d.deleteMessage}`, { method: "DELETE" });
        toast("Message deleted.");
        await refreshAll();
      }
      if (d.readMessage) {
        await api(`/api/admin/messages/${d.readMessage}`, {
          method: "PATCH",
          body: { is_read: Number(d.read) },
        });
        await refreshAll();
      }
    } catch (err) {
      toast(err.message, true);
    }
  });

  /* ---------------------------------------------------------- content forms */
  const lines = (text) =>
    String(text || "")
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);

  const REPEAT_CONFIG = {
    facts: {
      fields: ["label", "value"],
      placeholders: ["Label (e.g. Studying)", "Value (e.g. Grade 10)"],
    },
    timeline: {
      fields: ["step", "tag", "title", "desc"],
      placeholders: ["01", "Tag (e.g. Growth)", "Title / school name", "Description"],
      textareas: ["desc"],
    },
    groups: {
      fields: ["icon", "title", "level", "desc"],
      placeholders: ["Icon: cpu, code, js, book, brain, lang", "Skill title", "Level (e.g. Learning)", "Description"],
      textareas: ["desc"],
    },
  };

  function repeatRow(kind, data = {}) {
    const cfg = REPEAT_CONFIG[kind];
    const wrap = document.createElement("div");
    wrap.className = `repeat__item repeat__item--${kind}`.trim();
    wrap.innerHTML =
      cfg.fields
        .map((f) => {
          const ph = cfg.placeholders[cfg.fields.indexOf(f)] || f;
          const val = esc(data[f] || "");
          return (cfg.textareas || []).includes(f)
            ? `<textarea name="${f}" rows="2" placeholder="${ph}">${val}</textarea>`
            : `<input name="${f}" placeholder="${ph}" value="${val}">`;
        })
        .join("") + `<button type="button" class="btn btn--danger btn--sm repeat__del" data-remove>✕</button>`;
    wrap.querySelector("[data-remove]").addEventListener("click", () => wrap.remove());
    return wrap;
  }

  function renderRepeat(kind, items) {
    const container = $(`.repeat[data-repeat="${kind}"]`);
    if (!container) return;
    container.innerHTML = "";
    (items || []).forEach((item) => container.appendChild(repeatRow(kind, item)));
  }

  document.addEventListener("click", (e) => {
    const add = e.target.closest("[data-add]");
    if (!add) return;
    const kind = add.dataset.add;
    $(`.repeat[data-repeat="${kind}"]`).appendChild(repeatRow(kind));
  });

  function readRepeat(kind) {
    const cfg = REPEAT_CONFIG[kind];
    return $$(`.repeat[data-repeat="${kind}"] .repeat__item`).map((row) => {
      const obj = {};
      cfg.fields.forEach((f) => {
        obj[f] = $(`[name="${f}"]`, row)?.value.trim() || "";
      });
      return obj;
    });
  }

  function fillContentForms() {
    const { profile, about, skills, seo } = state.content;

    const setForm = (key, values) => {
      const form = $(`form[data-content="${key}"]`);
      if (!form) return;
      Object.entries(values).forEach(([name, value]) => {
        const input = form.elements[name];
        if (!input) return;
        input.value = Array.isArray(value) ? value.join("\n") : value ?? "";
      });
    };

    setForm("profile", profile);
    renderRepeat("facts", profile.facts);

    setForm("about", {
      ...about,
      paragraphs: about.paragraphs || [],
      interests: about.interests || [],
    });
    renderRepeat("timeline", about.timeline);

    setForm("skills", skills);
    renderRepeat("groups", skills.groups);

    setForm("seo", seo);
  }

  $$("form[data-content]").forEach((form) => {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const key = form.dataset.content;
      const msg = $(".form-message", form);
      const btn = $("button[type=submit]", form);
      const base = state.content[key] || {};
      const payload = { ...base };

      $$("input,textarea,select", form).forEach((el) => {
        if (!el.name) return;
        payload[el.name] = el.value;
      });

      if (key === "about") {
        payload.paragraphs = lines(payload.paragraphs);
        payload.interests = lines(payload.interests);
        payload.timeline = readRepeat("timeline").filter((t) => t.title || t.desc);
      }
      if (key === "skills") payload.groups = readRepeat("groups").filter((g) => g.title);
      if (key === "profile") payload.facts = readRepeat("facts").filter((f) => f.label || f.value);

      btn.disabled = true;
      msg.className = "form-message";
      msg.textContent = "Saving…";
      try {
        await api(`/api/admin/content/${key}`, { method: "PUT", body: payload });
        msg.className = "form-message is-ok";
        msg.textContent = "Saved — the live site is updated.";
        toast("Content saved.");
        const content = await api("/api/admin/content");
        state.content = content;
      } catch (err) {
        msg.className = "form-message is-error";
        msg.textContent = err.message;
      } finally {
        btn.disabled = false;
      }
    });
  });

  /* ------------------------------------------------------------ password form */
  $("#passwordForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const form = e.target;
    const msg = $(".form-message", form);
    const btn = $("button[type=submit]", form);
    btn.disabled = true;
    msg.className = "form-message";
    msg.textContent = "Updating…";
    try {
      await api("/api/admin/password", {
        method: "POST",
        body: { current: form.current.value, next: form.next.value },
      });
      form.reset();
      msg.className = "form-message is-ok";
      msg.textContent = "Password updated. Other sessions were signed out.";
      toast("Password updated.");
    } catch (err) {
      msg.className = "form-message is-error";
      msg.textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });

  /* -------------------------------------------------------------------- boot */
  (async function boot() {
    try {
      const me = await api("/api/admin/me");
      showApp(me.admin);
    } catch {
      showLogin();
    }
  })();
})();
