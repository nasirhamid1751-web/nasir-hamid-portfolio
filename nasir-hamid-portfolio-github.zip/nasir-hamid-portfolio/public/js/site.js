/* Nasir Hamid — site interactions (vanilla JS, no dependencies) */
(function () {
  "use strict";

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------------------------------------------------------------- mobile nav */
  const toggle = $("#navToggle");
  const menu = $("#mobileMenu");
  const nav = $("#nav");

  function setMenu(open) {
    if (!toggle || !menu) return;
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    menu.hidden = !open;
    document.body.style.overflow = open ? "hidden" : "";
  }

  if (toggle && menu) {
    toggle.addEventListener("click", () => setMenu(toggle.getAttribute("aria-expanded") !== "true"));
    $$("a", menu).forEach((a) => a.addEventListener("click", () => setMenu(false)));
    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape") setMenu(false);
    });
    window.addEventListener("resize", () => {
      if (window.innerWidth > 860) setMenu(false);
    });
  }

  /* ------------------------------------------------------- scroll UI feedback */
  const progress = $("#scrollProgress");
  const toTop = $("#toTop");

  function onScroll() {
    const y = window.scrollY;
    if (nav) nav.classList.toggle("is-stuck", y > 8);
    if (progress) {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      progress.style.width = max > 0 ? `${Math.min(100, (y / max) * 100)}%` : "0%";
    }
    if (toTop) toTop.hidden = y < 600;
  }

  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  if (toTop) {
    toTop.addEventListener("click", () =>
      window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" })
    );
  }

  /* ------------------------------------------------------- reveal on scroll */
  const reveals = $$(".reveal");
  if (reveals.length) {
    if (reduceMotion || !("IntersectionObserver" in window)) {
      reveals.forEach((el) => el.classList.add("is-in"));
    } else {
      const io = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-in");
              io.unobserve(entry.target);
            }
          });
        },
        { rootMargin: "0px 0px -8% 0px", threshold: 0.08 }
      );
      reveals.forEach((el) => io.observe(el));
    }
  }

  /* --------------------------------------------------- resource/video filters */
  $$(".filter").forEach((group) => {
    const buttons = $$(".filter__btn", group);
    const scope = group.parentElement;
    const items = $$("[data-category]", scope);
    const empty = $(".rgrid__empty", scope);

    buttons.forEach((btn) => {
      btn.addEventListener("click", () => {
        const filter = btn.dataset.filter;
        buttons.forEach((b) => {
          const on = b === btn;
          b.classList.toggle("is-active", on);
          b.setAttribute("aria-selected", String(on));
        });
        let visible = 0;
        items.forEach((item) => {
          const show = filter === "All" || item.dataset.category === filter;
          item.hidden = !show;
          if (show) visible += 1;
        });
        if (empty) empty.hidden = visible > 0;
      });
    });
  });

  /* ---------------------------------------------------------------- video modal */
  const modal = $("#videoModal");
  const frame = $("#videoFrame");

  function openVideo(id) {
    if (!modal || !frame || !id) return;
    frame.innerHTML = `<iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(
      id
    )}?autoplay=1&rel=0" title="Video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen loading="lazy"></iframe>`;
    if (typeof modal.showModal === "function") modal.showModal();
    else modal.setAttribute("open", "");
  }

  function closeVideo() {
    if (!modal) return;
    if (typeof modal.close === "function" && modal.open) modal.close();
    else modal.removeAttribute("open");
    if (frame) frame.innerHTML = "";
  }

  document.addEventListener("click", (e) => {
    const trigger = e.target.closest("[data-video]");
    if (trigger && trigger.dataset.video) {
      e.preventDefault();
      openVideo(trigger.dataset.video);
    }
    if (e.target === modal) closeVideo();
  });

  const closeBtn = $("#videoClose");
  if (closeBtn) closeBtn.addEventListener("click", closeVideo);
  if (modal) {
    modal.addEventListener("close", () => {
      if (frame) frame.innerHTML = "";
    });
    modal.addEventListener("cancel", closeVideo);
  }

  /* --------------------------------------------------------------- contact form */
  const form = $("#contactForm");
  if (form) {
    const status = $("#formStatus");
    const submit = $("button[type=submit]", form);

    const showStatus = (text, ok) => {
      if (!status) return;
      status.textContent = text;
      status.className = `cform__status ${ok ? "is-ok" : "is-error"}`;
    };

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      let valid = true;
      ["name", "email", "message"].forEach((field) => {
        const input = form.elements[field];
        if (!input) return;
        const bad =
          !input.value.trim() ||
          (field === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(input.value.trim())) ||
          (field === "message" && input.value.trim().length < 10);
        input.setAttribute("aria-invalid", String(bad));
        if (bad) valid = false;
      });
      if (!valid) {
        showStatus("Please check the highlighted fields and try again.", false);
        return;
      }

      submit.disabled = true;
      submit.style.opacity = "0.65";
      showStatus("Sending…", true);
      try {
        const res = await fetch("/api/contact", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });
        const json = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(json.error || "Something went wrong. Please email me instead.");
        form.reset();
        showStatus(json.message || "Message sent — thank you!", true);
      } catch (err) {
        showStatus(err.message, false);
      } finally {
        submit.disabled = false;
        submit.style.opacity = "";
      }
    });
  }

  /* -------------------------------------------------- active nav link on scroll */
  const sections = $$("section[id]");
  const navLinks = $$(".nav__links a");
  if (sections.length && navLinks.length && "IntersectionObserver" in window) {
    const spy = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const id = entry.target.id;
          navLinks.forEach((link) => {
            const href = link.getAttribute("href") || "";
            const match = href === `/#${id}` || href === `#${id}`;
            if (match) link.setAttribute("aria-current", "page");
            else if (!link.dataset.static) link.removeAttribute("aria-current");
          });
        });
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );
    sections.forEach((s) => spy.observe(s));
  }
})();
