# Fonts

Both typefaces are self-hosted (woff2, latin + latin-ext subsets) so the site makes **no
third-party font requests** — better privacy, better performance, and it works offline.

| Family | Weights used | Source | Licence |
| --- | --- | --- | --- |
| **Archivo** (display) | 600–900 | https://fonts.google.com/specimen/Archivo | SIL Open Font License 1.1 — see `OFL-archivo.txt` |
| **Inter** (body) | 400–700 | https://fonts.google.com/specimen/Inter | SIL Open Font License 1.1 — see `OFL-inter.txt` |

`fonts.css` declares each family as a variable font (`font-weight: 100 900`) and uses
`unicode-range` so the latin-ext file is only downloaded when a page contains those characters.

To swap in a different typeface, replace the `.woff2` files, update `fonts.css`, and change
`--font-display` / `--font-body` in `public/css/site.css`.
