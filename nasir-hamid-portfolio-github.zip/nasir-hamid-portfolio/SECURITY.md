# Security policy

## Reporting a problem

If you find a vulnerability in this site, email **nasirhamid1751@gmail.com** with the details and
steps to reproduce. Please don't open a public issue for security problems. You'll get a reply
as soon as possible.

## What is protected, and how

| Area | Implementation |
| --- | --- |
| Admin password | `scrypt` (N=16384, 64-byte key) with a per-user random salt. Never stored or logged in plain text. |
| Sessions | 32-byte random token; only its SHA-256 hash is stored in the database. Cookie is `HttpOnly`, `SameSite=Strict`, `Secure` in production, 7-day expiry, revoked on logout and on password change. |
| Brute force | 8 failed logins per IP per 15 minutes; generic error message; constant-time hash comparison. |
| CSRF | `SameSite=Strict` cookie **plus** a required `x-requested-with: fetch` header and an origin check on every state-changing request. |
| File uploads | Extension + MIME + magic-byte sniffing, random server-side filenames, 25 MB (PDF) / 5 MB (image) limits, files stored outside the public web root and streamed by the app. |
| Path traversal | Uploaded files are resolved, then verified to live inside the uploads directory before being served. |
| Headers | Content-Security-Policy with a per-request nonce, `X-Content-Type-Options`, `X-Frame-Options` (production), `Referrer-Policy`, `Permissions-Policy`, `Cross-Origin-Opener-Policy`. |
| Spam | Contact-form honeypot field, server-side validation, 5 messages/hour per IP. |
| Exposure | `/admin` and `/api/admin/*` send `noindex` and are excluded in `robots.txt`; the dashboard requires a live session for every request. |

## Deploying safely

1. Change the admin password immediately after the first login and delete `data/ADMIN-CREDENTIALS.txt`.
2. Run with `NODE_ENV=production` and HTTPS (the session cookie becomes `Secure`).
3. Keep `data/` and `.env` out of version control — they are already in `.gitignore`.
4. Back up `data/` regularly; it holds the database and every uploaded PDF.
