#!/usr/bin/env python3
"""Builds every optimized image asset used by the site from the two source photos."""
import os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

SRC_PORTRAIT = "/home/user/uploads/file_00000000bbfc7208999e1c026cc06d20.png"   # 1024x1536
SRC_WORKSPACE = "/home/user/uploads/file_00000000e9908211b1351e3b43a49811.png"  # 1536x1024
OUT = "/home/user/nasir-portfolio/public/images"
FONT_DIR = os.path.dirname(os.path.abspath(__file__))

os.makedirs(OUT, exist_ok=True)

INK = (11, 13, 12)
PAPER = (246, 245, 240)
MINT = (0, 216, 154)


def save_variants(img, name, widths, quality=82):
    for w in widths:
        scale = w / img.width
        h = round(img.height * scale)
        resized = img.resize((w, h), Image.LANCZOS)
        resized.save(f"{OUT}/{name}-{w}.webp", "WEBP", quality=quality, method=6)
        resized.save(f"{OUT}/{name}-{w}.jpg", "JPEG", quality=quality, optimize=True,
                     progressive=True)


def square_crop(img, cx, cy, size):
    half = size // 2
    left = max(0, min(img.width - size, cx - half))
    top = max(0, min(img.height - size, cy - half))
    return img.crop((left, top, left + size, top + size))


def main():
    portrait = Image.open(SRC_PORTRAIT).convert("RGB")
    workspace = Image.open(SRC_WORKSPACE).convert("RGB")

    # --- Hero portrait: 4:5 crop keeps the head and shoulders nicely framed -----
    target_ratio = 4 / 5
    w, h = portrait.size
    new_h = int(w / target_ratio)
    if new_h <= h:
        top = 0
        crop = portrait.crop((0, top, w, top + new_h))
    else:
        new_w = int(h * target_ratio)
        left = (w - new_w) // 2
        crop = portrait.crop((left, 0, left + new_w, h))
    save_variants(crop, "hero-portrait", [640, 900, 1200])

    # --- Tall portrait used inside the About section ---------------------------
    tall = square_crop(portrait, 512, 620, 1000)
    save_variants(tall, "portrait-square", [480, 720])

    # --- Workspace / meeting photo (About + project cards) ---------------------
    save_variants(workspace, "workspace", [800, 1200, 1600])

    # --- Icon / avatar / favicons ---------------------------------------------
    icon = square_crop(portrait, 500, 600, 780).resize((512, 512), Image.LANCZOS)
    icon.save(f"{OUT}/icon-512.png", optimize=True)
    icon.resize((192, 192), Image.LANCZOS).save(f"{OUT}/icon-192.png", optimize=True)
    icon.resize((180, 180), Image.LANCZOS).save(f"{OUT}/apple-touch-icon.png", optimize=True)
    icon.resize((32, 32), Image.LANCZOS).save(f"{OUT}/favicon-32.png", optimize=True)
    icon.resize((16, 16), Image.LANCZOS).save(f"{OUT}/favicon-16.png", optimize=True)
    icon.save(f"{OUT}/favicon.ico", sizes=[(16, 16), (32, 32), (48, 48), (64, 64)])
    # small round avatar for meta / admin chrome
    icon.resize((160, 160), Image.LANCZOS).save(f"{OUT}/avatar-160.jpg", "JPEG", quality=88)

    # --- Open Graph card (1200x630) ------------------------------------------
    og = Image.new("RGB", (1200, 630), INK)
    d = ImageDraw.Draw(og)
    # soft mint glow
    glow = Image.new("RGB", (1200, 630), INK)
    gd = ImageDraw.Draw(glow)
    gd.ellipse((620, -180, 1420, 620), fill=(10, 90, 70))
    glow = glow.filter(ImageFilter.GaussianBlur(120))
    og = Image.blend(og, glow, 0.55)
    d = ImageDraw.Draw(og)
    
    # portrait panel on the right
    panel = Image.new("RGB", (400, 500), (18, 22, 20))
    face = square_crop(portrait, 512, 560, 860).resize((400, 500), Image.LANCZOS)
    mask = Image.new("L", (400, 500), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, 399, 499), radius=34, fill=255)
    og.paste(face, (720, 96), mask)
    d.rounded_rectangle((720, 96, 1119, 595), radius=34, outline=(255, 255, 255, 40), width=2)

    archivo = ImageFont.truetype(f"{FONT_DIR}/Archivo.ttf", 104)
    archivo_md = ImageFont.truetype(f"{FONT_DIR}/Archivo.ttf", 38)
    inter = ImageFont.truetype(f"{FONT_DIR}/Inter.ttf", 27)
    inter_sm = ImageFont.truetype(f"{FONT_DIR}/Inter.ttf", 22)

    d.text((84, 150), "NASIR", font=archivo, fill=PAPER)
    d.text((84, 258), "HAMID", font=archivo, fill=PAPER)
    d.text((84, 396), "Student · Self-taught developer", font=archivo_md, fill=MINT)
    d.text((84, 466), "Grade 10 learner building a foundation in", font=inter, fill=(190, 194, 190))
    d.text((84, 502), "computer science — one project at a time.", font=inter, fill=(190, 194, 190))
    d.rounded_rectangle((84, 78, 250, 118), radius=20, fill=MINT)
    d.text((104, 88), "PORTFOLIO", font=inter_sm, fill=INK)
    og.save(f"{OUT}/og-image.jpg", "JPEG", quality=88, optimize=True)
    print("images built ->", OUT)


if __name__ == "__main__":
    main()
