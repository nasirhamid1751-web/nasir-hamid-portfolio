#!/usr/bin/env python3
"""Generates Nasir Hamid's CV PDF (public/cv/nasir-hamid-cv.pdf) using only facts
already published on his existing portfolio website."""
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = "/home/user/nasir-portfolio/public/cv"
os.makedirs(OUT_DIR, exist_ok=True)
OUT = os.path.join(OUT_DIR, "nasir-hamid-cv.pdf")

pdfmetrics.registerFont(TTFont("Archivo", os.path.join(HERE, "Archivo.ttf")))
pdfmetrics.registerFont(TTFont("Inter", os.path.join(HERE, "Inter.ttf")))

INK = HexColor("#0B0D0C")
MINT = HexColor("#00B27F")
GREY = HexColor("#4A4F4C")
LINE = HexColor("#D9D8D2")
PAPER = HexColor("#F6F5F0")

W, H = A4
c = canvas.Canvas(OUT, pagesize=A4)
c.setTitle("Nasir Hamid — CV")
c.setAuthor("Nasir Hamid")
c.setSubject("CV of Nasir Hamid, Grade 10 student and self-taught computer science learner")

# ---------- header band ----------
c.setFillColor(INK)
c.rect(0, H - 62 * mm, W, 62 * mm, stroke=0, fill=1)
c.setFillColor(MINT)
c.circle(W - 26 * mm, H - 20 * mm, 16 * mm, stroke=0, fill=1)
c.setFillColor(INK)
c.setFont("Inter", 7.5)
c.drawCentredString(W - 26 * mm, H - 20.8 * mm, "GRADE 10")

c.setFillColor(HexColor("#FFFFFF"))
c.setFont("Archivo", 30)
c.drawString(20 * mm, H - 26 * mm, "NASIR HAMID")
c.setFillColor(MINT)
c.setFont("Inter", 10)
c.drawString(20 * mm, H - 34 * mm, "STUDENT  ·  SELF-TAUGHT COMPUTER SCIENCE LEARNER")
c.setFillColor(HexColor("#B9BDB9"))
c.setFont("Inter", 8.5)
c.drawString(20 * mm, H - 43 * mm, "nasirhamid1751@gmail.com")
c.drawString(20 * mm, H - 49 * mm, "0332-6162675")
c.drawString(20 * mm, H - 55 * mm, "github.com/nasirhamid1751-web")

x = 20 * mm
y = H - 74 * mm


def section(title):
    global y
    y -= 4 * mm
    c.setFillColor(MINT)
    c.setFont("Inter", 7.5)
    c.drawString(x, y, title.upper())
    y -= 2.6 * mm
    c.setStrokeColor(LINE)
    c.setLineWidth(0.7)
    c.line(x, y, W - 20 * mm, y)
    y -= 6 * mm


def para(text, size=9, leading=13.5, color=GREY, gap=2.5):
    global y
    c.setFillColor(color)
    c.setFont("Inter", size)
    max_w = W - 40 * mm
    words = text.split()
    line = ""
    for word in words:
        trial = (line + " " + word).strip()
        if pdfmetrics.stringWidth(trial, "Inter", size) > max_w:
            c.drawString(x, y, line)
            y -= leading
            line = word
        else:
            line = trial
    if line:
        c.drawString(x, y, line)
        y -= leading
    y -= gap


def bullet(label, text):
    global y
    c.setFillColor(MINT)
    c.circle(x + 1.2 * mm, y + 1.1 * mm, 0.9 * mm, stroke=0, fill=1)
    c.setFillColor(INK)
    c.setFont("Inter", 9)
    c.drawString(x + 5 * mm, y, label)
    c.setFillColor(GREY)
    c.setFont("Inter", 8.6)
    c.drawString(x + 5 * mm + pdfmetrics.stringWidth(label, "Inter", 9) + 2 * mm, y, text)
    y -= 5.4 * mm


section("Profile")
para("Dedicated and enthusiastic Grade 10 student with a strong academic record and a genuine "
     "passion for computer science. Self-taught learner who enjoys exploring how computers and "
     "software actually work, and who is working towards a future in technology through "
     "consistent, disciplined daily study.")

section("Education")
bullet("Government Primary School, Star Jummat Kharmana", "Primary education — strong academic foundation, consistently excellent results")
bullet("Government High School, Dogar", "Secondary education — critical thinking, independent learning and personal growth")
bullet("Independent Study — Computer Science", "Self-directed learning beyond the classroom: technology, computing and web fundamentals")
bullet("Grade 10", "Currently enrolled — preparing for board examinations")

section("Areas of Focus")
para("Computer science fundamentals · Web fundamentals (HTML, CSS, JavaScript) · Digital learning "
     "and research · English language development · Critical thinking and problem solving")

section("Interests")
para("Learning and improving English language skills · Exploring computer science and technology "
     "concepts · Educational and documentary content on YouTube · Staying current with new ideas, "
     "knowledge and innovations")

section("Vision")
para("Continuous learning, hard work and determination are the keys to success. I am committed to "
     "developing my knowledge and skills every day so I can contribute positively to society and "
     "reach my future goals. Education is the foundation of success, and learning never stops.")

# ---------- footer ----------
c.setFillColor(PAPER)
c.rect(0, 0, W, 20 * mm, stroke=0, fill=1)
c.setFillColor(GREY)
c.setFont("Inter", 7.5)
c.drawString(20 * mm, 8 * mm, "Nasir Hamid  ·  Portfolio & resources: nasirhamid1751-web.github.io")
c.setFillColor(MINT)
c.drawRightString(W - 20 * mm, 8 * mm, "Code. Build. Repeat.")

c.showPage()
c.save()
print("CV written:", OUT, os.path.getsize(OUT), "bytes")
