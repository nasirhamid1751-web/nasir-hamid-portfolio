#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Full acceptance test (end-to-end, mutating).
#
# Boots this checkout against a throwaway DATA_DIR and exercises every feature:
# public pages, SEO, auth, PDF upload/validation/download, projects, videos,
# publish/unpublish/delete, contact form, content editing, password change and
# static assets. It never touches your real data/ folder, so it is safe to run
# on any clone.
#
#   npm ci && bash scripts/acceptance-test.sh
#   PORT=3400 bash scripts/acceptance-test.sh
#
# Exits non-zero if any check fails.
# ---------------------------------------------------------------------------
set -uo pipefail

PORT="${PORT:-3322}"
BASE="http://127.0.0.1:$PORT"
PROJECT="${PROJECT:-$(cd "$(dirname "$0")/.." && pwd)}"
RUNDIR="${TMPDIR:-/tmp}/portfolio-acceptance"
DATA="$RUNDIR/data"
JAR="$RUNDIR/cookies.txt"
FETCH="$RUNDIR/fetched.html"
JSON="$RUNDIR/j.py"
PASS=0
FAIL=0

ok()    { PASS=$((PASS+1)); printf '  \033[32mPASS\033[0m %s\n' "$1"; }
bad()   { FAIL=$((FAIL+1)); printf '  \033[31mFAIL\033[0m %s\n' "$1"; }
check() { if [ "$2" = "$3" ]; then ok "$1 ($3)"; else bad "$1 (expected [$3], got [$2])"; fi; }
code()  { curl -s -o /dev/null -w "%{http_code}" "$@"; }
fetch() { curl -s "$1" > "$FETCH"; }
has()   { grep -q -- "$1" "$FETCH"; }
hasnt() { ! grep -q -- "$1" "$FETCH"; }
jget()  { curl -s -b "$JAR" "$BASE$1" > "$FETCH"; python3 "$JSON" "$2"; }

kill "$(cat "$RUNDIR/server.pid" 2>/dev/null)" 2>/dev/null
rm -rf "$RUNDIR"
mkdir -p "$RUNDIR"

cat > "$JSON" <<PY
import json, sys
rows = json.load(open("$FETCH"))
expr = sys.argv[1]
env = {"rows": rows, "len": len}
print(eval(expr, env))
PY

echo "== 1. Boot from an empty checkout"
if curl -s -m 2 -o /dev/null "$BASE/healthz"; then
  echo "ERROR: something is already listening on $BASE — stop it first (a stale server makes every check meaningless)."
  exit 99
fi
cd "$PROJECT" || { echo "missing $PROJECT"; exit 1; }
export NODE_ENV=production PORT=$PORT DATA_DIR=$DATA \
       ADMIN_EMAIL=owner@example.com ADMIN_PASSWORD='SuperSecret12345' INSECURE_COOKIES=1
node server/index.js > "$RUNDIR/server.log" 2>&1 &
echo $! > "$RUNDIR/server.pid"
for i in $(seq 1 40); do curl -fsS "$BASE/healthz" >/dev/null 2>&1 && break; sleep 0.5; done

check "health endpoint" "$(curl -s "$BASE/healthz" | cut -c1-11)" '{"ok":true,'
check "sqlite database created" "$([ -f "$DATA/portfolio.db" ] && echo yes || echo no)" "yes"
check "upload folders created" "$([ -d "$DATA/uploads/pdf" ] && echo yes || echo no)" "yes"

echo "== 2. Public pages are server-rendered"
for p in / /projects /resources /videos /admin /sitemap.xml /robots.txt /site.webmanifest; do
  check "GET $p" "$(code "$BASE$p")" "200"
done
for p in /projects/personal-portfolio-v1 /resources/nasir-hamid-cv /videos/cs50x-2024-lecture-0 /download-cv; do
  check "GET $p" "$(code "$BASE$p")" "200"
done
check "unknown page returns 404" "$(code "$BASE/nope")" "404"

echo "== 3. SEO, metadata and content"
fetch "$BASE/"
has "Nasir Hamid"                                  && ok "name rendered"                || bad "name rendered"
has 'property="og:image" content="http'            && ok "absolute Open Graph image"    || bad "absolute Open Graph image"
has 'application/ld+json'                          && ok "JSON-LD Person schema"        || bad "JSON-LD Person schema"
has 'rel="canonical"'                              && ok "canonical link"               || bad "canonical link"
has 'name="description"'                           && ok "meta description"             || bad "meta description"
hasnt 'nonce="undefined"'                          && ok "CSP nonce resolved"           || bad "CSP nonce resolved"
has "Government High School"                       && ok "seeded biography present"     || bad "seeded biography present"
has "Download CV"                                  && ok "CV button present"            || bad "CV button present"
fetch "$BASE/sitemap.xml"
has "/resources/nasir-hamid-cv"                    && ok "sitemap lists resources"      || bad "sitemap lists resources"
curl -sI "$BASE/" | grep -qi "content-security-policy" && ok "CSP header sent"           || bad "CSP header sent"

echo "== 4. Admin area is locked down"
check "admin API without session"      "$(code "$BASE/api/admin/stats")" "401"
check "login without anti-CSRF header" "$(code -X POST "$BASE/api/admin/login" -H 'Content-Type: application/json' -d '{"email":"owner@example.com","password":"SuperSecret12345"}')" "403"
check "login with wrong password"      "$(code -X POST "$BASE/api/admin/login" -H 'Content-Type: application/json' -H 'x-requested-with: fetch' -d '{"email":"owner@example.com","password":"wrong"}')" "401"
LOGIN=$(curl -s -c "$JAR" -X POST "$BASE/api/admin/login" -H 'Content-Type: application/json' -H 'x-requested-with: fetch' -d '{"email":"owner@example.com","password":"SuperSecret12345"}')
case "$LOGIN" in *'"ok":true'*) ok "credentials from env accepted" ;; *) bad "credentials from env accepted ($LOGIN)" ;; esac
grep -q "nh_sid" "$JAR" && ok "session cookie stored" || bad "session cookie stored"
check "admin API with session" "$(code -b "$JAR" "$BASE/api/admin/stats")" "200"
check "no password file when env password is set" "$([ -f "$DATA/ADMIN-CREDENTIALS.txt" ] && echo yes || echo no)" "no"

echo "== 5. PDF resource: upload, validate, publish, download"
printf '%%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<</Root 1 0 R>>\n' > $RUNDIR/valid.pdf
printf 'GIF89a this is not a pdf' > $RUNDIR/fake.pdf
{ printf 'x'; head -c 27000000 /dev/urandom; } > $RUNDIR/huge.bin

U1=$(curl -s -b "$JAR" -X POST "$BASE/api/admin/resources" -H 'x-requested-with: fetch' \
      -F "title=Class 10 Physics Notes" -F "category=Notes" -F "description=Test upload" \
      -F "published=1" -F "file=@$RUNDIR/valid.pdf;type=application/pdf")
case "$U1" in *'"ok":true'*) ok "valid PDF accepted" ;; *) bad "valid PDF accepted ($U1)" ;; esac
U2=$(curl -s -b "$JAR" -X POST "$BASE/api/admin/resources" -H 'x-requested-with: fetch' \
      -F "title=Fake PDF" -F "file=@$RUNDIR/fake.pdf;type=application/pdf")
case "$U2" in *"not a valid PDF"*) ok "renamed non-PDF rejected (magic bytes)" ;; *) bad "renamed non-PDF rejected ($U2)" ;; esac
U3=$(curl -s -b "$JAR" -X POST "$BASE/api/admin/resources" -H 'x-requested-with: fetch' \
      -F "title=Too Big" -F "file=@$RUNDIR/huge.bin;type=application/pdf")
case "$U3" in *"error"*) ok "oversized upload rejected" ;; *) bad "oversized upload rejected ($U3)" ;; esac

fetch "$BASE/resources"
has "Class 10 Physics Notes" && ok "resource listed publicly" || bad "resource listed publicly"
fetch "$BASE/resources/class-10-physics-notes"
has "Download PDF" && has "Class 10 Physics Notes" && ok "resource detail page" || bad "resource detail page"
curl -s -D $RUNDIR/h.txt -o $RUNDIR/dl.pdf "$BASE/download/class-10-physics-notes"
check "download body is the PDF" "$(head -c 5 $RUNDIR/dl.pdf)" "%PDF-"
grep -qi "content-disposition: attachment" $RUNDIR/h.txt && ok "download forces attachment" || bad "download forces attachment"
check "download counter incremented" "$(jget /api/admin/resources "[r['downloads'] for r in rows if r['slug']=='class-10-physics-notes'][0]")" "1"

echo "== 6. Projects and videos"
P1=$(curl -s -b "$JAR" -X POST "$BASE/api/admin/projects" -H 'x-requested-with: fetch' \
      -F "title=Science Fair Poster" -F "summary=Made in Grade 9" \
      -F "description=First paragraph.

Second paragraph." -F "tech=HTML, CSS" -F "live_url=https://example.com" -F "featured=1" -F "published=1")
case "$P1" in *'"ok":true'*) ok "project created" ;; *) bad "project created ($P1)" ;; esac
fetch "$BASE/projects/science-fair-poster"
has "Second paragraph." && ok "project description renders paragraphs" || bad "project description renders paragraphs"

V1=$(curl -s -b "$JAR" -X POST "$BASE/api/admin/videos" -H 'x-requested-with: fetch' \
      -F "title=How I Study CS" -F "category=Tutorials" -F "youtube=https://youtu.be/3LPJfIKxwWc" -F "published=1")
case "$V1" in *'"ok":true'*) ok "video created from YouTube link" ;; *) bad "video created from YouTube link ($V1)" ;; esac
VTHUMB=$(jget /api/admin/videos "[v['thumb'] or 'none' for v in rows if v['slug']=='how-i-study-cs'][0]")
case "$VTHUMB" in /media/images/*) ok "YouTube thumbnail stored locally" ;; *) bad "YouTube thumbnail stored locally ($VTHUMB)" ;; esac
fetch "$BASE/videos"
has "How I Study CS" && ok "video listed publicly" || bad "video listed publicly"
V2=$(curl -s -b "$JAR" -X POST "$BASE/api/admin/videos" -H 'x-requested-with: fetch' \
      -F "title=Bad Link" -F "youtube=not-a-link")
case "$V2" in *"valid YouTube"*) ok "invalid YouTube link rejected" ;; *) bad "invalid YouTube link rejected ($V2)" ;; esac

echo "== 7. Publish / unpublish / delete"
PID=$(jget /api/admin/projects "[p['id'] for p in rows if p['slug']=='science-fair-poster'][0]")
curl -s -b "$JAR" -X PUT "$BASE/api/admin/projects/$PID" -H 'Content-Type: application/json' -H 'x-requested-with: fetch' -d '{"published":"0"}' > /dev/null
check "unpublished project page is 404" "$(code "$BASE/projects/science-fair-poster")" "404"
curl -s -b "$JAR" -X PUT "$BASE/api/admin/projects/$PID" -H 'Content-Type: application/json' -H 'x-requested-with: fetch' -d '{"published":"1"}' > /dev/null
check "republished project page is 200" "$(code "$BASE/projects/science-fair-poster")" "200"
DEL=$(curl -s -b "$JAR" -X DELETE "$BASE/api/admin/projects/$PID" -H 'x-requested-with: fetch')
case "$DEL" in *'"ok":true'*) ok "project deleted" ;; *) bad "project deleted ($DEL)" ;; esac
check "deleted project is gone" "$(code "$BASE/projects/science-fair-poster")" "404"

echo "== 8. Contact form and dashboard inbox"
C1=$(curl -s -X POST "$BASE/api/contact" -H 'Content-Type: application/json' \
     -d '{"name":"Ahmad","email":"ahmad@example.com","subject":"Salam","message":"Thanks for the resources."}')
case "$C1" in *'"ok":true'*) ok "message accepted" ;; *) bad "message accepted ($C1)" ;; esac
check "invalid email rejected" "$(code -X POST "$BASE/api/contact" -H 'Content-Type: application/json' -d '{"name":"x","email":"bad","message":"too short"}')" "400"
check "short message rejected" "$(code -X POST "$BASE/api/contact" -H 'Content-Type: application/json' -d '{"name":"Valid Name","email":"a@b.co","message":"short"}')" "400"
check "honeypot silently accepted" "$(code -X POST "$BASE/api/contact" -H 'Content-Type: application/json' -d '{"name":"Bot","email":"b@example.com","message":"spam spam spam spam","company":"x"}')" "200"
check "inbox has exactly 1 real message" "$(jget /api/admin/messages 'len(rows)')" "1"

echo "== 9. Site content editing (no code changes)"
CS=$(curl -s -b "$JAR" -X PUT "$BASE/api/admin/content/profile" -H 'Content-Type: application/json' -H 'x-requested-with: fetch' -d '{"tagline":"Edited tagline for the integrity test."}')
case "$CS" in *'"ok":true'*) ok "content saved" ;; *) bad "content saved ($CS)" ;; esac
fetch "$BASE/"
has "Edited tagline for the integrity test." && ok "change live on the public site" || bad "change live on the public site"
has "nasirhamid1751@gmail.com"                && ok "partial update kept other fields" || bad "partial update kept other fields"
UNK=$(curl -s -b "$JAR" -X PUT "$BASE/api/admin/content/unknown" -H 'Content-Type: application/json' -H 'x-requested-with: fetch' -d '{"x":1}')
case "$UNK" in *"Unknown content"*) ok "unknown content block rejected" ;; *) bad "unknown content block rejected ($UNK)" ;; esac

echo "== 10. Password change and logout"
check "weak password rejected"        "$(code -b "$JAR" -X POST "$BASE/api/admin/password" -H 'Content-Type: application/json' -H 'x-requested-with: fetch' -d '{"current":"SuperSecret12345","next":"short"}')" "400"
check "wrong current password"        "$(code -b "$JAR" -X POST "$BASE/api/admin/password" -H 'Content-Type: application/json' -H 'x-requested-with: fetch' -d '{"current":"nope","next":"AnotherGood12345"}')" "400"
PW=$(curl -s -b "$JAR" -c "$JAR" -X POST "$BASE/api/admin/password" -H 'Content-Type: application/json' -H 'x-requested-with: fetch' -d '{"current":"SuperSecret12345","next":"AnotherGood12345"}')
case "$PW" in *'"ok":true'*) ok "password changed" ;; *) bad "password changed ($PW)" ;; esac
curl -s -b "$JAR" -c "$JAR" -X POST "$BASE/api/admin/logout" -H 'x-requested-with: fetch' > /dev/null
check "session invalid after logout"  "$(code -b "$JAR" "$BASE/api/admin/stats")" "401"
rm -f "$JAR"
check "login with the new password"   "$(code -X POST "$BASE/api/admin/login" -H 'Content-Type: application/json' -H 'x-requested-with: fetch' -d '{"email":"owner@example.com","password":"AnotherGood12345"}')" "200"

echo "== 11. Static assets"
for a in /css/site.css /css/admin.css /js/site.js /js/admin.js /fonts/fonts.css \
         /fonts/archivo-latin.woff2 /fonts/inter-latin.woff2 /images/og-image.jpg \
         /images/favicon.ico /images/apple-touch-icon.png /cv/nasir-hamid-cv.pdf; do
  check "asset $a" "$(code "$BASE$a")" "200"
done

echo "== 12. Server log is clean"
if grep -qiE "unhandled|TypeError|ReferenceError|ECONNREFUSED" $RUNDIR/server.log; then
  bad "server log clean"
  grep -iE "unhandled|TypeError|ReferenceError" $RUNDIR/server.log | head -5
else
  ok "server log clean"
fi

kill "$(cat $RUNDIR/server.pid)" 2>/dev/null

echo
echo "================ RESULT: $PASS passed, $FAIL failed ================"
exit $FAIL
