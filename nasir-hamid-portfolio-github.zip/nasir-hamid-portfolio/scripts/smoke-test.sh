#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Quick smoke test for a running instance of the site (read-only).
#
#   BASE=https://your-domain.com bash scripts/smoke-test.sh
#   bash scripts/smoke-test.sh                 # defaults to http://localhost:3000
#
# Safe to run against production: it only issues GETs plus a couple of
# deliberately invalid requests (which create nothing).
# ---------------------------------------------------------------------------
set -uo pipefail

BASE="${BASE:-http://localhost:3000}"
TMP="$(mktemp)"
PASS=0
FAIL=0

ok()    { PASS=$((PASS+1)); printf '  \033[32mPASS\033[0m %s\n' "$1"; }
bad()   { FAIL=$((FAIL+1)); printf '  \033[31mFAIL\033[0m %s\n' "$1"; }
check() { if [ "$2" = "$3" ]; then ok "$1 ($3)"; else bad "$1 (expected [$3], got [$2])"; fi; }
code()  { curl -s -o /dev/null -w "%{http_code}" --max-time 15 "$@"; }
fetch() { curl -s --max-time 15 "$1" > "$TMP"; }
has()   { grep -q -- "$1" "$TMP"; }

echo "Smoke-testing $BASE"

echo "== Pages"
for p in / /projects /resources /videos /admin /healthz /sitemap.xml /robots.txt /site.webmanifest; do
  check "GET $p" "$(code "$BASE$p")" "200"
done
check "unknown path is 404" "$(code "$BASE/this-page-does-not-exist")" "404"
check "health check reports ok" "$(curl -s --max-time 10 "$BASE/healthz" | cut -c1-11)" '{"ok":true,'

echo "== Metadata"
fetch "$BASE/"
has "Nasir Hamid"                            && ok "name rendered"             || bad "name rendered"
has 'property="og:image" content="http'      && ok "absolute og:image"         || bad "absolute og:image"
has 'application/ld+json'                    && ok "JSON-LD present"           || bad "JSON-LD present"
has 'rel="canonical"'                        && ok "canonical present"         || bad "canonical present"
has 'nonce="undefined"'                      && bad "CSP nonce resolved"       || ok "CSP nonce resolved"
fetch "$BASE/sitemap.xml"
has "<urlset"                                && ok "sitemap is XML"            || bad "sitemap is XML"

echo "== Security headers"
H=$(curl -sI --max-time 15 "$BASE/")
for h in content-security-policy x-content-type-options referrer-policy; do
  if printf '%s' "$H" | grep -qi "^$h"; then ok "$h"; else bad "$h"; fi
done

echo "== Admin is locked"
check "admin API without session"      "$(code "$BASE/api/admin/stats")" "401"
check "login without anti-CSRF header" "$(code -X POST "$BASE/api/admin/login" -H 'Content-Type: application/json' -d '{"email":"x@y.z","password":"whatever"}')" "403"
check "invalid contact message"        "$(code -X POST "$BASE/api/contact" -H 'Content-Type: application/json' -d '{"name":"x","email":"bad","message":"short"}')" "400"

echo "== Assets"
fetch "$BASE/sitemap.xml"
for a in /css/site.css /js/site.js /fonts/fonts.css /images/favicon.ico /cv/nasir-hamid-cv.pdf; do
  check "asset $a" "$(code "$BASE$a")" "200"
done

rm -f "$TMP"
echo
echo "================ RESULT: $PASS passed, $FAIL failed ================"
exit $FAIL
