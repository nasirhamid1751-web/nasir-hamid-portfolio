# Nasir Hamid — Portfolio & Resource Hub

A fast, responsive personal portfolio with a **private admin dashboard** for publishing projects,
PDF resources and videos — no code editing needed after setup.

- **Public site:** hero → about → skills → projects → resources → videos → contact, plus real,
  crawlable pages for every project, resource and video.
- **Admin dashboard:** `/admin` — upload PDFs, add videos, manage projects, read contact messages,
  edit every line of site copy.
- **No external services:** one Node process + one SQLite file. No database server, no S3, no CMS
  subscription, no build step.

> Everything in this repository is the complete, working project — server, templates, styles,
> scripts, images, fonts, deployment configs and CI. Clone it and it runs.

[![CI](https://github.com/nasirhamid1751-web/nasir-hamid-portfolio/actions/workflows/ci.yml/badge.svg)](.github/workflows/ci.yml)
![Node](https://img.shields.io/badge/node-%E2%89%A520-3c873a)
![License](https://img.shields.io/badge/license-MIT-blue)

---

## Contents

1. [Quick start (2 minutes)](#1-quick-start-2-minutes)
2. [First login and the dashboard](#2-first-login-and-the-dashboard)
3. [What goes on GitHub vs. what stays private](#3-what-goes-on-github-vs-what-stays-private)
4. [Putting this on GitHub](#4-putting-this-on-github)
5. [Project structure](#5-project-structure)
6. [Deployment](#6-deployment)
7. [Configuration reference](#7-configuration-reference)
8. [Backups and moving the site](#8-backups-and-moving-the-site)
9. [How it is built](#9-how-it-is-built)
10. [Security](#10-security)
11. [SEO, performance and accessibility](#11-seo-performance-and-accessibility)
12. [Tests and continuous integration](#12-tests-and-continuous-integration)
13. [Optional: regenerating images or the CV](#13-optional-regenerating-images-or-the-cv)
14. [Content notes (what came from where)](#14-content-notes-what-came-from-where)
15. [License](#15-license)

---

## 1. Quick start (2 minutes)

**Requirements:** Node.js **20 or newer** (`.nvmrc` pins 22) and ~150 MB of disk for
`node_modules`. Nothing else — SQLite ships inside the app.

```bash
npm ci            # install dependencies (npm install works too)
npm start         # http://localhost:3000
```

| URL | What it is |
| --- | --- |
| http://localhost:3000 | Public site |
| http://localhost:3000/admin | Admin dashboard |
| http://localhost:3000/healthz | Health check (returns `{"ok":true}` when the DB answers) |
| http://localhost:3000/sitemap.xml | Sitemap |
| http://localhost:3000/robots.txt | Robots |

On the very first run the app creates `data/portfolio.db`, seeds the site content, and creates one
admin account. **The generated password is printed in the terminal and written to
`data/ADMIN-CREDENTIALS.txt`:**

```
email:    nasirhamid1751@gmail.com
password: <generated, shown once>
```

Log in → **Security → Change password** → set your own password → delete
`data/ADMIN-CREDENTIALS.txt`.

To choose the credentials yourself, set `ADMIN_EMAIL` and `ADMIN_PASSWORD` **before the first run**
(a `.env` file or real environment variables — see [§7](#7-configuration-reference)). If those are
set, no password file is created.

---

## 2. First login and the dashboard

Everything you save appears on the public site immediately — no rebuild, no redeploy.

| Tab | What you can do |
| --- | --- |
| **Overview** | Downloads, counts, storage used, recent activity |
| **Projects** | Add / edit / delete, upload a preview image, mark *Featured*, publish or unpublish |
| **Resources** | Upload a PDF (max 25 MB), pick a category, description + optional thumbnail, download counts |
| **Videos** | Paste a YouTube link (or any external video URL), category/playlist, publish |
| **Messages** | Read contact-form messages, mark read/unread, reply by email, delete |
| **Site content** | Hero copy, about paragraphs, interests, education timeline, skill cards, SEO title/description/site URL |
| **Security** | Change password, review how the login is protected |

**Adding a PDF resource.** *Resources → + Upload resource* → title, category
(Documents / Notes / Presentations / Guides / Books), short description, the PDF (optional
thumbnail) → keep **Published** ticked → **Upload resource**. The server verifies it is a real PDF
(magic bytes, not just a renamed file), enforces the 25 MB cap, stores it under
`data/uploads/pdf/` with a random filename, and creates `/resources/your-title` with a working
download at `/download/your-title`.

> **Your CV** is the resource with the slug `nasir-hamid-cv`; the hero **Download CV** button
> (`/cv`) always serves that one. Publish a new CV by editing that resource and uploading the new
> PDF. If you change its slug, update *Site content → CV resource slug* too.

**Adding a video.** *Videos → + Add video* → paste any of these into *YouTube link or ID*:

```
https://www.youtube.com/watch?v=3LPJfIKxwWc
https://youtu.be/3LPJfIKxwWc
3LPJfIKxwWc
```

The thumbnail is downloaded and stored locally (so no third-party image requests), and playback
uses `youtube-nocookie.com` in a modal. For anything else (Vimeo, Drive, a self-hosted file) leave
YouTube empty and fill **External video URL**. Videos sharing a **Category** get a filter chip on
`/videos`.

---

## 3. What goes on GitHub vs. what stays private

This repository is designed so that **publishing it leaks nothing personal**. The rule:

> **Code and public design assets are public. Anything that is generated, secret, personal or
> uploaded at runtime stays on your machine / your server.**

### ✅ Safe to commit (and is already in this repo)

| Path | Why it is safe |
| --- | --- |
| `server/` | Application code |
| `public/css/`, `public/js/`, `public/admin.html` | Styles and scripts |
| `public/fonts/` | Archivo + Inter woff2, SIL Open Font License (licence files included) |
| `public/images/` | The optimised design photos/icons built from your two source images |
| `public/cv/nasir-hamid-cv.pdf` | The public CV — anyone can download it from the live site anyway |
| `scripts/` | Python helpers that generated the images and the CV |
| `data/.gitkeep` | Empty placeholder so the runtime folder exists after cloning |
| `README.md`, `DEPLOYMENT.md`, `SECURITY.md`, `LICENSE` | Documentation |
| `.env.example` | Variable **names** only, every value blank or a placeholder |
| `.gitignore`, `.nvmrc`, `.editorconfig`, `.gitattributes` | Tooling config |
| `package.json`, `package-lock.json` | Dependency manifest + lockfile |
| `Dockerfile`, `.dockerignore`, `Procfile` | Container/process config |
| `render.yaml`, `railway.json`, `fly.toml` | Deployment blueprints |
| `.github/workflows/ci.yml` | CI pipeline |

### 🔒 Never commit — already blocked by `.gitignore`

| Path | What it is | Why private |
| --- | --- | --- |
| `data/portfolio.db` (+ `-wal`, `-shm`) | The live SQLite database | Contains contact-form messages from visitors, draft/unpublished content |
| `data/uploads/pdf/*` | PDFs you uploaded | Personal documents you chose to publish — keep the master copies yourself |
| `data/uploads/images/*` | Thumbnails you uploaded | Same |
| `data/ADMIN-CREDENTIALS.txt` | The generated admin password | **A live password in plain text** |
| `.env` (any `.env.*`) | Real environment values | Contains `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `SITE_URL` |
| `node_modules/` | Installed dependencies | Recreated by `npm ci`; ~150 MB of noise |
| `*.pem`, `*.key`, `*.p12`, `secrets*.txt`, `credentials*.txt`, `serviceAccount*.json` | Keys and secrets | Obviously private |
| Logs, `dist/`, `build/`, `coverage/`, caches | Generated artefacts | No value in history |

Two practical consequences:

1. **Uploaded files live only on the machine/server that received them.** They are not in Git, so
   they are not in the repo backup either — copy `data/` separately (see [§8](#8-backups-and-moving-the-site)).
2. **Never paste a real password into `.env.example`.** If you ever commit a secret by accident,
   change that password immediately — Git history keeps old blobs even after a later delete.

Check before your first push:

```bash
git status --short          # nothing under data/ or node_modules/ should appear
git ls-files | grep -E '(^data/(?!\.gitkeep)|\.env$|CREDENTIALS|node_modules)' || echo "clean"
```

---

## 4. Putting this on GitHub

The project has no leftover history — start a fresh repository from it:

```bash
cd nasir-portfolio

git init -b main
git add .
git commit -m "Nasir Hamid portfolio, resource library and admin dashboard"

# create an empty repo on github.com first (no README, no .gitignore), then:
git remote add origin https://github.com/<your-username>/nasir-hamid-portfolio.git
git push -u origin main
```

If you already cloned this ZIP into an existing repo, `git add . && git commit` is enough — the
`.gitignore` keeps the private files out automatically.

**Recommended repository settings**

- Description: *Personal portfolio, resource library and video hub with a private admin dashboard.*
- Topics: `portfolio`, `express`, `sqlite`, `nodejs`, `personal-website`
- Keep the repo **public** — it contains no secrets. If you prefer it private, hosting providers
  will need read access to the repository (GitHub App authorisation handles this).
- Enable **Actions** (the CI workflow runs automatically on push and pull requests).

---

## 5. Project structure

```
nasir-portfolio/
├── server/
│   ├── index.js          Express app: public pages, JSON API, admin API, security headers
│   ├── render.js         Server-side HTML templates (fast first paint, real SEO)
│   ├── db.js             SQLite schema, seed data, queries
│   ├── auth.js           scrypt hashing, DB-backed sessions, login rate limiting
│   ├── upload.js         multer storage, type/size/magic-byte validation, remote thumbnails
│   └── content-seed.js   Initial editorial content (carried over from the previous portfolio)
├── public/
│   ├── css/site.css      Public design system (tokens, layout, components, responsive)
│   ├── css/admin.css     Dashboard styles
│   ├── js/site.js        Nav, scroll reveals, filters, video modal, contact form
│   ├── js/admin.js       Dashboard logic (talks to /api/admin)
│   ├── admin.html        Dashboard shell
│   ├── images/           Optimised photos, favicons, OG card
│   ├── fonts/            Self-hosted Archivo + Inter (no Google Fonts requests)
│   └── cv/               The CV PDF served by /download-cv
├── scripts/              Python helpers that generated the images and the CV
├── data/                 Created at runtime — portfolio.db + uploads/ (NOT in Git)
├── .github/workflows/    CI pipeline
├── deploy configs        render.yaml · railway.json · fly.toml · Procfile · Dockerfile
├── .env.example          Every supported variable, no real values
├── DEPLOYMENT.md         Step-by-step hosting guide + costs
└── SECURITY.md           Security model and reporting
```

**Database tables:** `settings` (site content blocks as JSON), `admins`, `sessions`, `projects`,
`resources`, `videos`, `messages`.

---

## 6. Deployment

You need a host that keeps a **persistent disk** — SQLite and uploaded PDFs live on that disk.
Configuration files for three providers are included and ready to use.

| Provider | Config included | Persistent storage | Typical cost |
| --- | --- | --- | --- |
| **Render** (Blueprint) | `render.yaml` | 1 GB disk mounted at `/var/data` — *paid instance type required* | $7 / month |
| **Railway** | `railway.json` | Attach a volume at `DATA_DIR` | ~$5 / month (trial credit first) |
| **Fly.io** | `fly.toml` | `fly volumes create portfolio_data --size 1` | $2–5 / month |
| **Any VPS** (Hetzner, DigitalOcean, Vultr) | `Dockerfile`, `Procfile` | Local disk | $4–6 / month |
| **Your own machine / Raspberry Pi** | — | Local disk | free |

> **Free tiers without a disk** (Render free web service, Railway without a volume, Vercel,
> Netlify, Heroku) will lose the database and uploads on every restart or redeploy. They can host
> this app, but the site resets to the seed content. Use one of the options above for anything real.

Full instructions — GitHub → hosting, environment variables, custom domain, HTTPS, backups and
troubleshooting — are in **[DEPLOYMENT.md](DEPLOYMENT.md)**.

Minimum production environment (details in [§7](#7-configuration-reference)):

```
NODE_ENV=production
PORT=3000
DATA_DIR=/var/data          # must be on the persistent disk
ADMIN_EMAIL=you@example.com
ADMIN_PASSWORD=<long random>
SITE_URL=https://your-domain.com
```

---

## 7. Configuration reference

All configuration is environment variables (a `.env` file is read if present; see `.env.example`).
**Names only — no real secrets are stored in this repo.**

| Variable | Default | Purpose |
| --- | --- | --- |
| `PORT` | `3000` | HTTP port |
| `NODE_ENV` | `development` | `production` enables `Secure` cookies and strict framing headers |
| `DATA_DIR` | `./data` | Where the database and uploads live — point this at your persistent disk |
| `ADMIN_EMAIL` | the seeded address | Admin login, applied when the account is created (and on password reset flows) |
| `ADMIN_PASSWORD` | random | Initial password. If omitted, one is generated and written to `data/ADMIN-CREDENTIALS.txt` |
| `SITE_URL` | request host | Absolute base URL used for canonical links, Open Graph and the sitemap. **Set this in production** |
| `INSECURE_COOKIES` | unset | `1` allows session cookies over plain HTTP (local testing only) |

---

## 8. Backups and moving the site

Everything stateful is inside `DATA_DIR`:

```bash
# on the server (or locally) — stop the app first for a clean copy
tar czf portfolio-backup-$(date +%F).tar.gz data/
```

- `data/portfolio.db` — content, messages, sessions, admin password hash
- `data/uploads/` — the PDFs and thumbnails you uploaded

Restore by extracting `data/` next to the app (or onto the new server's disk at `DATA_DIR`) and
starting the app. To move to another host: copy `data/`, set the same `DATA_DIR` and `SITE_URL`,
redeploy. Download counters and messages carry over.

---

## 9. How it is built

**Request flow**

1. A visitor requests `/` → Express queries SQLite → `render.js` returns complete HTML (no
   client-side data fetching, so pages are fast and properly indexed).
2. `/api/contact` validates and stores the message in `messages` → it appears in your dashboard.
3. `/download/<slug>` streams the PDF from `data/uploads/pdf/` with
   `Content-Disposition: attachment` and increments the download counter.
4. You save something in `/admin` → JSON request to `/api/admin/*` → SQLite row updated → the very
   next page view shows it. There is no rebuild step.

**Routes**

| Public | Admin |
| --- | --- |
| `/` `/projects` `/projects/:slug` | `/admin` |
| `/resources` `/resources/:slug` `/download/:slug` `/view/:slug` | `/api/admin/login` `/logout` `/me` `/stats` |
| `/videos` `/videos/:slug` `/cv` `/download-cv` | `/api/admin/{projects,resources,videos}[/:id]` |
| `/api/site` `/api/projects` `/api/resources` `/api/videos` `/api/contact` | `/api/admin/messages[/:id]` `/api/admin/content[/:key]` `/api/admin/password` |
| `/healthz` `/sitemap.xml` `/robots.txt` `/site.webmanifest` `/media/images/*` | |

---

## 10. Security

| Area | Protection |
| --- | --- |
| Passwords | `scrypt` (N=16384) with per-user salt; never stored in plain text |
| Sessions | 32-byte random token, SHA-256 hashed in the DB, `HttpOnly` + `SameSite=Strict` cookie, 7-day expiry, revocable |
| Login | 8 failed attempts per IP per 15 minutes, generic error messages, constant-time comparison |
| CSRF | Same-origin check + required `x-requested-with: fetch` header on every mutation |
| Uploads | MIME + extension + **magic-byte** verification, random server-side filenames, 25 MB (PDF) / 5 MB (image) caps, files stored outside the web root and streamed by the app |
| Headers | CSP with per-request nonce, `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy` |
| Admin | `/admin` and `/api/admin/*` are `noindex`; every editor endpoint requires a live session |
| Contact form | Server-side validation, honeypot field, 5 messages/hour per IP |

**Before going live:** `NODE_ENV=production`, your own admin password, HTTPS, and
`SITE_URL` set. See [SECURITY.md](SECURITY.md) for the full model and how to report an issue.

---

## 11. SEO, performance and accessibility

- Server-rendered HTML, one `<h1>` per page, logical heading order, semantic landmarks
- Unique `<title>` + meta description per page, canonical URLs, Open Graph + Twitter cards,
  JSON-LD `Person` schema, `sitemap.xml`, `robots.txt`, `site.webmanifest`
- Self-hosted fonts (no third-party requests), `font-display: swap`, preloaded woff2
- Responsive `srcset`/`webp` images, `loading="lazy"` below the fold, `fetchpriority="high"` on the
  hero portrait
- CSS ≈ 40 KB, JS ≈ 14 KB, no framework, no build step
- Keyboard accessible (skip link, visible focus rings, labelled forms, `aria-*` state on menus,
  filters and modal), motion disabled under `prefers-reduced-motion`
- Favicon and app icons generated from the supplied portrait

---

## 12. Tests and continuous integration

`.github/workflows/ci.yml` runs on every push and pull request on Node 20 and 22:

1. `npm ci` and a syntax check of every `server/*.js` and `public/js/*.js` file
2. Boots the server and asserts `200` on `/`, `/projects`, `/resources`, `/videos`, `/admin`,
   `/sitemap.xml`, `/robots.txt`, `/site.webmanifest`
3. Asserts the home page contains the name, `og:image`, JSON-LD, canonical URL, and no
   `nonce="undefined"`
4. Asserts `/api/admin/*` returns `401` without a session and `403` without the anti-CSRF header
5. Logs in, uploads a real PDF (accepted), a renamed fake PDF (rejected), confirms the resource is
   public and `/download/...` serves `%PDF`
6. Posts a valid and an invalid contact message (`200` / `400`)

Two scripts you can run yourself:

```bash
# 1. Read-only check of a live instance (safe against production)
BASE=https://your-domain.com bash scripts/smoke-test.sh   # default http://localhost:3000

# 2. Full end-to-end suite: boots the app against a throwaway DATA_DIR and
#    exercises every feature (77 assertions). Run it after npm ci.
bash scripts/acceptance-test.sh
```

`npm ci && bash scripts/acceptance-test.sh` on a fresh clone is the fastest way to prove the whole
project still works after your own changes.

---

## 13. Optional: regenerating images or the CV

The optimised photos, favicons and CV PDF are already built and committed. You only need the
helpers if you replace the source photos or edit the CV text:

```bash
pip install pillow reportlab fonttools
npm run assets      # rebuilds public/images/* and public/cv/nasir-hamid-cv.pdf
```

---

## 14. Content notes (what came from where)

All personal facts come from the previous portfolio
(`nasirhamid1751-web.github.io/Nasir-Portfolio`), rewritten for clarity:

- Name, Grade 10 status, schools (Government Primary School Star Jummat Kharmana, Government High
  School Dogar), independent CS study
- Email `nasirhamid1751@gmail.com`, phone `0332-6162675`
- Interests, vision and quote — kept in his own words
- GitHub link (`github.com/nasirhamid1751-web`) — the account that hosts the previous site
- Skills are labelled honestly (*Exploring / Foundational / Learning / Developing / Improving*)
- **Seeded projects:** Portfolio v1 (his live site) and this site (v2)
- **Seeded resources:** his CV, generated from the same information
- **Seeded videos:** three CS50 lectures marked *Recommended watching* — replace or delete them from
  the dashboard when you publish your own
- "Based in Pakistan" and the availability line are placeholders — edit them in
  **Site content → Hero & profile**

Nothing was invented: no fake qualifications, awards, experience or client work.

---

## 15. License

Code: **MIT** (see [LICENSE](LICENSE)). Photos, biography, CV and personal text remain
© Nasir Hamid — the licence covers the code, not the person. Fonts are under the SIL Open Font
License (see `public/fonts/`).
