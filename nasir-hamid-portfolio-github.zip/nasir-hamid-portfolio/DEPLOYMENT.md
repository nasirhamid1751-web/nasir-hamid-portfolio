# Deployment guide

The app is a single Node.js process (Node **20+**) with an embedded SQLite database and a local
uploads folder. That means: **one server, one disk, no external services.** Any host that can run
Node or a Docker image can run it.

Two things must survive every restart and redeploy:

1. `data/portfolio.db` — the database (content, messages, download counts, admin password)
2. `data/uploads/` — the PDFs and thumbnails you uploaded from the dashboard

Both live inside `DATA_DIR`. Everything else (`node_modules`, `public/`) is rebuilt from the repo.

This repository ships ready-to-use config for each provider below:

| File | Used by |
| --- | --- |
| `render.yaml` | Render Blueprint |
| `railway.json` | Railway |
| `fly.toml` | Fly.io |
| `Dockerfile` | Any container host / VPS |
| `Procfile` | Heroku-style PaaS (`web: node server/index.js`) |
| `.github/workflows/ci.yml` | GitHub Actions (tests before you deploy) |

---

## 0. Before you deploy — three rules

1. **Push the repository (public or private), never your `data/` folder.** The `.gitignore` already
   excludes the database, uploads, `.env` and the generated password file. See
   [README §3](README.md#3-what-goes-on-github-vs-what-stays-private).
2. **The host must offer persistent storage.** Without a disk/volume, the database and uploads are
   wiped on every deploy, restart or idle sleep — the site silently resets to the seed content.
3. **Set `ADMIN_EMAIL` + `ADMIN_PASSWORD` as environment variables on the host** so the first boot
   creates your account instead of writing a random password into a file you cannot read
   conveniently. Change the password from the dashboard afterwards if you like.

Environment variables used by the app (all optional except the storage ones):

| Variable | Production value | Notes |
| --- | --- | --- |
| `NODE_ENV` | `production` | Enables `Secure` cookies and strict framing headers |
| `PORT` | platform-provided (often `3000`) | Most hosts inject this — do not hard-code it |
| `DATA_DIR` | the mounted disk path | **Must point at the persistent disk** |
| `ADMIN_EMAIL` | `nasirhamid1751@gmail.com` | Used when the admin account is created |
| `ADMIN_PASSWORD` | a long random string | Only read on first boot / password reset |
| `SITE_URL` | `https://your-domain.com` | Canonical links, Open Graph, sitemap |
| `INSECURE_COOKIES` | leave unset | `1` only for plain-HTTP local testing |

Every option below exposes `GET /healthz` (returns `{"ok":true}` when the database answers, `503`
otherwise). Point the host's health check at it.

---

## Option A — Render (Blueprint, ~$7/month)

`render.yaml` describes the whole service, so Render can create it in one step.

1. Push the repository to GitHub.
2. [render.com](https://render.com) → **New → Blueprint** → pick the repository → **Apply**.
   Render reads `render.yaml` and creates a Node web service with:
   - build `npm ci`, start `node server/index.js`, health check `/healthz`
   - a 1 GB disk named `portfolio-data` mounted at `/var/data` with `DATA_DIR=/var/data`
3. Fill the values Render asks for (`ADMIN_EMAIL`, `ADMIN_PASSWORD`, `SITE_URL` — they are marked
   `sync: false` so they are never stored in Git).
4. Open `https://<your-service>.onrender.com/admin` and sign in.

**Important:** the `plan: starter` instance type is what makes a disk available. Render's **free**
web services have no persistent disk (and sleep after inactivity), so uploads and content would be
lost — use Starter, or one of the options below.

Cost: Starter instance $7/month + $0.25/GB disk.

If you prefer clicking to blueprints: **New → Web Service** → build `npm ci`, start
`node server/index.js`, then *Disks → Add Disk* (mount `/var/data`) and add `DATA_DIR=/var/data`.

---

## Option B — Railway (~$5/month)

1. Push the repository to GitHub.
2. [railway.app](https://railway.app) → **New Project → Deploy from GitHub repo**. `railway.json`
   sets the builder (Nixpacks), build `npm ci`, start `node server/index.js` and health check
   `/healthz`.
3. **Add a volume** — service → *Variables/Settings → Volumes* → mount at **`/app/data`** (Railway's
   default working directory). `DATA_DIR` defaults to `./data`, which resolves to that path; set
   `DATA_DIR=/app/data` explicitly if you mount somewhere else.
4. **Variables:** `NODE_ENV=production`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `SITE_URL`.
5. Settings → **Networking → Generate Domain** (or attach your own).
6. Open `/admin` and sign in.

Cost: Hobby plan from $5/month including a small volume; a portfolio uses a fraction of that.
Without a volume, everything resets on redeploy.

---

## Option C — Fly.io (~$2–5/month)

`fly.toml` is already configured: app `nasir-hamid-portfolio`, region `fra`, internal port 3000,
`DATA_DIR=/app/data`, volume `portfolio_data` mounted at `/app/data`, health check `/healthz`.

```bash
# one-time: install flyctl, then
fly launch --no-deploy --copy-config      # reuse the existing fly.toml
fly volumes create portfolio_data --size 1 --region fra
fly secrets set ADMIN_EMAIL=nasirhamid1751@gmail.com ADMIN_PASSWORD='a-long-random-password'

fly deploy
fly open                                   # https://nasir-hamid-portfolio.fly.dev
```

Notes:

- To rename the app, change `app = "..."` in `fly.toml` before the first `fly deploy`.
- Change `primary_region` if `fra` (Frankfurt) is far from your visitors — `sin` (Singapore) or
  `bom` (Mumbai) are closer to Pakistan and are both supported Fly regions.
- A volume is pinned to one region and one machine; `fly scale count 1` keeps it simple.
- `fly ssh console` drops you into the machine if you need to inspect `DATA_DIR`.

Cost: a shared-cpu-1x 512 MB machine is a few dollars a month plus $0.15/GB of volume.

---

## Option D — Budget VPS (Hetzner / DigitalOcean / Contabo, $4–6/month)

```bash
# on the server (Ubuntu 24.04)
sudo apt update && sudo apt install -y nginx git
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs

sudo git clone <your-repo> /var/www/portfolio
cd /var/www/portfolio
sudo npm ci --omit=dev
```

Create `/etc/systemd/system/portfolio.service`:

```ini
[Unit]
Description=Nasir Hamid portfolio
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/www/portfolio
ExecStart=/usr/bin/node server/index.js
Environment=NODE_ENV=production
Environment=PORT=3000
Environment=DATA_DIR=/var/www/portfolio/data
Environment=ADMIN_EMAIL=you@example.com
Environment=ADMIN_PASSWORD=change-me-before-first-boot
Environment=SITE_URL=https://your-domain.com
Restart=always
User=www-data

[Install]
WantedBy=multi-user.target
```

```bash
sudo chown -R www-data:www-data /var/www/portfolio
sudo systemctl daemon-reload && sudo systemctl enable --now portfolio
sudo systemctl status portfolio --no-pager     # should say active (running)
curl -s localhost:3000/healthz                 # {"ok":true,...}
```

Nginx reverse proxy (`/etc/nginx/sites-available/portfolio`, then symlink into `sites-enabled`):

```nginx
server {
  listen 80;
  server_name your-domain.com;
  client_max_body_size 30M;          # allow 25 MB PDF uploads

  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Real-IP $remote_addr;
  }
}
```

`sudo nginx -t && sudo systemctl reload nginx`, then free HTTPS:

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

Cost: VPS $4–6/month, domain ~$10–12/year.

---

## Option E — Docker anywhere

```bash
docker build -t nasir-portfolio .
docker run -d --name portfolio -p 3000:3000 \
  -v portfolio_data:/app/data \
  -e NODE_ENV=production \
  -e ADMIN_EMAIL=nasirhamid1751@gmail.com \
  -e ADMIN_PASSWORD='a-long-random-password' \
  -e SITE_URL=https://your-domain.com \
  nasir-portfolio

docker ps                      # STATUS should show (healthy) — the image health-checks /healthz
curl -s localhost:3000/healthz
```

The image already sets `DATA_DIR=/app/data` and declares `VOLUME /app/data`; the named volume
`portfolio_data` keeps your database and PDFs. Works on any VPS, NAS or container host.

---

## Which host should I pick?

| Host | Persistent disk included | Effort | Monthly |
| --- | --- | --- | --- |
| Render (Blueprint) | only on paid instance types | low | ~$7 |
| Railway | volume, any plan | low | ~$5 |
| Fly.io | volume, small machines | medium | ~$2–5 |
| VPS + nginx | local disk | medium | ~$4–6 |
| Render/Railway/Heroku **free** | ❌ none | low | $0 — **resets on every deploy** |
| Vercel / Netlify | ❌ none (and they are not built for long-running Node + SQLite) | — | not suitable |

If $0 is a hard requirement, run it at home (an old laptop or Raspberry Pi behind Cloudflare
Tunnel) rather than on a free tier that deletes your data.

---

## Custom domain

1. Buy a domain (Cloudflare Registrar, Namecheap — ~$10–12/year).
2. Point it at your host (Railway/Render give you a CNAME; a VPS needs an `A` record).
3. Set `SITE_URL=https://your-domain.com` **or** paste the URL in
   **Admin → Site content → SEO & domain → Site URL**. This drives canonical links, Open Graph URLs
   and the sitemap.
4. Submit `https://your-domain.com/sitemap.xml` in Google Search Console.

Without that setting the site still works — it derives the base URL from the incoming request.

---

## Backups (do this monthly)

Everything you care about lives in `DATA_DIR`:

```bash
# on the server — clean copy while the app keeps running
sqlite3 /var/www/portfolio/data/portfolio.db ".backup /tmp/portfolio-$(date +%F).db"
tar czf /tmp/uploads-$(date +%F).tar.gz -C /var/www/portfolio/data uploads
```

Or stop the app and copy the whole folder:

```bash
sudo systemctl stop portfolio
sudo tar czf /tmp/backup-$(date +%F).tar.gz -C /var/www/portfolio data
sudo systemctl start portfolio
```

Download the archive somewhere off the server (Google Drive, another machine, an encrypted private
repo — **not** the public repository). Restoring: stop the app, replace `DATA_DIR`, start the app.

On Render/Railway/Fly you cannot shell in as easily — snapshot the disk/volume from the dashboard,
or add the same `sqlite3 .backup` command to a scheduled job.

---

## External services you might add (all optional)

| Service | Why | Cost |
| --- | --- | --- |
| **Nothing** | The site is complete as-is | **$0** |
| Domain | Professional address | ~$10–12 / year |
| Railway / Render / Fly / VPS | Hosting with a disk | $2–7 / month |
| Cloudflare (free plan) | DNS, CDN, caching, extra DDoS protection | $0 |
| Google Search Console | Indexing + search analytics | $0 |
| Plausible / Umami | Privacy-friendly analytics | $0 self-hosted, ~$9/mo cloud |
| Cloudflare R2 / S3 | Only if your PDFs outgrow ~1 GB | ~$0.015 / GB / month |
| Email (Resend / Brevo) | Only if you want contact-form notifications by email — currently messages are stored in your dashboard | Free tier available |
| UptimeRobot | Downtime alerts | $0 |

> Contact-form emails: messages are saved to the database and shown in the dashboard, which needs
> no third-party service. If you later want them emailed to you, add Resend's free tier
> (`npm i resend`) and call it inside the `/api/contact` handler.

---

## Troubleshooting

| Symptom | Cause / fix |
| --- | --- |
| Site resets after every deploy | No persistent disk/volume, or `DATA_DIR` does not point at it |
| `EACCES` / `SQLITE_CANTOPEN` on boot | `DATA_DIR` is not writable by the app user (fix ownership, e.g. `chown -R www-data`) |
| Uploads fail with 400 | File is not a real PDF, or larger than 25 MB (raise `client_max_body_size` in nginx too) |
| Cannot log in after redeploy | `ADMIN_PASSWORD` only applies on first boot; the stored hash wins. Reset via the dashboard, or stop the app, delete the `admins` rows with sqlite3, and boot again |
| Cookies not set behind a proxy | Serve over HTTPS and set `NODE_ENV=production`; keep `INSECURE_COOKIES` unset |
| Health check fails | Database not reachable — check `DATA_DIR` and logs from `npm start` |
| `better-sqlite3` build error | Node too old (need 20+) or missing build tools; on Debian/Ubuntu `apt install python3 make g++` |

---

## Launch checklist

- [ ] `npm ci && npm start` works locally and `/admin` loads
- [ ] `bash scripts/smoke-test.sh` passes against the deployed URL
- [ ] Admin password changed from the generated one; `data/ADMIN-CREDENTIALS.txt` deleted
- [ ] `NODE_ENV=production` and HTTPS enabled (cookie becomes `Secure`)
- [ ] `SITE_URL` set to the real domain
- [ ] Persistent disk/volume mounted and `DATA_DIR` pointing at it
- [ ] `ADMIN_EMAIL` / `ADMIN_PASSWORD` set as host environment variables (never in Git)
- [ ] Seeded *Recommended watching* videos replaced or kept intentionally
- [ ] Your CV uploaded to the `nasir-hamid-cv` resource
- [ ] Test: upload a PDF, download it, add a project, send a test message, then delete them
- [ ] Submit the sitemap to Google Search Console
- [ ] Monthly backup of `DATA_DIR` scheduled
