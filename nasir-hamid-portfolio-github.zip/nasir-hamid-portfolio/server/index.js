/**
 * Nasir Hamid — portfolio server
 * Express + SQLite. Public pages are server-rendered; /admin is a private,
 * cookie-authenticated dashboard that talks to the JSON API.
 */
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const express = require("express");

// Load .env before anything reads process.env (db.js/auth.js read it at require time).
require("./env").loadEnvFile();

const { db, DATA_DIR, UPLOAD_DIR, getSetting, setSetting, init, uniqueSlug } = require("./db");
const auth = require("./auth");
const {
  uploadFields,
  validateFiles,
  cleanup,
  removeStored,
  removeThumb,
  fetchYouTubeThumb,
  MAX_PDF,
} = require("./upload");
const render = require("./render");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const PROD = process.env.NODE_ENV === "production";
app.disable("x-powered-by");
app.set("trust proxy", 1);

/* --------------------------------------------------------------- bootstrapping */
init();
auth.ensureAdmin();

/* -------------------------------------------------------------------- helpers */
const PUBLIC_DIR = path.join(__dirname, "..", "public");
/**
 * Absolute base URL for canonical links / sitemap.
 * Priority: Site content → SEO setting → SITE_URL env → the incoming request host
 * (so the site is correct on any domain without configuration).
 */
const siteUrl = (req) => {
  const configured = (getSetting("seo", {}).siteUrl || process.env.SITE_URL || "").trim();
  const fallback = req ? `${req.protocol}://${req.get("host")}` : `http://localhost:${PORT}`;
  return (configured || fallback).replace(/\/$/, "");
};
const profile = () => getSetting("profile", {});
const about = () => getSetting("about", {});
const skills = () => getSetting("skills", { groups: [] });
const seo = () => getSetting("seo", {});

const parseProject = (r) =>
  r && {
    ...r,
    tech: (() => {
      try {
        return JSON.parse(r.tech || "[]");
      } catch {
        return [];
      }
    })(),
  };

const queries = {
  projects: (all = false) =>
    db
      .prepare(
        `SELECT * FROM projects ${all ? "" : "WHERE published = 1"} ORDER BY featured DESC, sort ASC, created_at DESC`
      )
      .all()
      .map(parseProject),
  projectBySlug: (slug) => parseProject(db.prepare("SELECT * FROM projects WHERE slug = ?").get(slug)),
  resources: (all = false) =>
    db
      .prepare(
        `SELECT * FROM resources ${all ? "" : "WHERE published = 1"} ORDER BY created_at DESC`
      )
      .all(),
  resourceBySlug: (slug) =>
    db.prepare("SELECT * FROM resources WHERE slug = ? AND published = 1").get(slug),
  videos: (all = false) =>
    db
      .prepare(`SELECT * FROM videos ${all ? "" : "WHERE published = 1"} ORDER BY featured DESC, created_at DESC`)
      .all(),
  videoBySlug: (slug) => db.prepare("SELECT * FROM videos WHERE slug = ? AND published = 1").get(slug),
};

/** Resolves a stored resource file path to an absolute path on disk. */
function resolveFile(stored) {
  if (!stored) return null;
  if (stored.startsWith("public/")) {
    const abs = path.join(__dirname, "..", stored);
    return fs.existsSync(abs) ? abs : null;
  }
  const abs = path.join(DATA_DIR, stored);
  return abs.startsWith(UPLOAD_DIR) && fs.existsSync(abs) ? abs : null;
}

/* ------------------------------------------------------------------- middleware */
app.use(express.json({ limit: "200kb" }));
app.use(express.urlencoded({ extended: false, limit: "200kb" }));

// Minimal cookie parser (keeps the dependency list short).
app.use((req, res, next) => {
  const header = req.headers.cookie;
  req.cookies = {};
  if (header) {
    for (const part of header.split(";")) {
      const idx = part.indexOf("=");
      if (idx > 0) req.cookies[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
    }
  }
  next();
});

// Security headers + per-request CSP nonce for the inline JSON-LD block.
app.use((req, res, next) => {
  const nonce = crypto.randomBytes(16).toString("base64");
  res.locals.nonce = nonce;
  res.setHeader("X-Content-Type-Options", "nosniff");
  // Production: refuse to be framed (clickjacking). Development/preview: allow the
  // sandbox preview iframe to render the site.
  if (PROD) res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  res.setHeader(
    "Content-Security-Policy",
    [
      "default-src 'self'",
      `script-src 'self' 'nonce-${nonce}'`,
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: https://i.ytimg.com",
      "font-src 'self'",
      "connect-src 'self'",
      "frame-src https://www.youtube-nocookie.com https://www.youtube.com",
      "media-src 'self'",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      PROD ? "frame-ancestors 'self'" : "frame-ancestors 'self' https: http:",
    ].join("; ")
  );
  next();
});

// Static assets — long cache for fingerprint-free but immutable media.
app.use(
  "/images",
  express.static(path.join(PUBLIC_DIR, "images"), { maxAge: "30d", immutable: false })
);
app.use("/fonts", express.static(path.join(PUBLIC_DIR, "fonts"), { maxAge: "365d", immutable: true }));
app.use("/css", express.static(path.join(PUBLIC_DIR, "css"), { maxAge: "1h" }));
app.use("/js", express.static(path.join(PUBLIC_DIR, "js"), { maxAge: "1h" }));
app.use("/cv", express.static(path.join(PUBLIC_DIR, "cv"), { maxAge: "1d" }));

// Uploaded thumbnails
app.use(
  "/media/images",
  express.static(path.join(UPLOAD_DIR, "images"), { maxAge: "30d", fallthrough: false })
);

/* ------------------------------------------------------------------- SEO files */
app.get("/robots.txt", (req, res) => {
  res.type("text/plain").send(
    `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api/\n\nSitemap: ${siteUrl(req)}/sitemap.xml\n`
  );
});

app.get("/site.webmanifest", (req, res) => {
  res.type("application/manifest+json").send(
    JSON.stringify({
      name: "Nasir Hamid — Portfolio",
      short_name: "Nasir Hamid",
      description: seo().description || "Portfolio and resource library of Nasir Hamid.",
      start_url: "/",
      display: "standalone",
      background_color: "#0B0D0C",
      theme_color: "#0B0D0C",
      icons: [
        { src: "/images/icon-192.png", sizes: "192x192", type: "image/png" },
        { src: "/images/icon-512.png", sizes: "512x512", type: "image/png" },
        { src: "/images/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
      ],
    })
  );
});

app.get("/sitemap.xml", (req, res) => {
  const base = siteUrl(req);
  const urls = [
    { loc: "/", priority: "1.0", changefreq: "weekly" },
    { loc: "/projects", priority: "0.9", changefreq: "weekly" },
    { loc: "/resources", priority: "0.9", changefreq: "weekly" },
    { loc: "/videos", priority: "0.8", changefreq: "weekly" },
    ...queries.projects().map((p) => ({ loc: `/projects/${p.slug}`, priority: "0.7", lastmod: p.updated_at })),
    ...queries.resources().map((r) => ({ loc: `/resources/${r.slug}`, priority: "0.7", lastmod: r.updated_at })),
    ...queries.videos().map((v) => ({ loc: `/videos/${v.slug}`, priority: "0.6", lastmod: v.updated_at })),
  ];
  const body = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls
  .map(
    (u) => `  <url>
    <loc>${base}${u.loc}</loc>${u.lastmod ? `\n    <lastmod>${String(u.lastmod).slice(0, 10)}</lastmod>` : ""}
    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`
  )
  .join("\n")}
</urlset>`;
  res.type("application/xml").send(body);
});

/* ----------------------------------------------------------------- public pages */
app.use((req, res, next) => {
  req.nonce = res.locals.nonce;
  next();
});

app.get("/", (req, res) => {
  res.send(
    render.homePage({
      nonce: req.nonce,
      profile: profile(),
      about: about(),
      skills: skills(),
      projects: queries.projects(),
      resources: queries.resources(),
      videos: queries.videos(),
      siteUrl: siteUrl(req),
    })
  );
});

app.get("/projects", (req, res) => {
  res.send(
    render.projectsPage({
      nonce: req.nonce,
      projects: queries.projects(),
      profile: profile(),
      siteUrl: siteUrl(req),
    })
  );
});

app.get("/projects/:slug", (req, res, next) => {
  const project = queries.projectBySlug(req.params.slug);
  if (!project || !project.published) return next();
  res.send(
    render.projectPage({
      nonce: req.nonce,
      project,
      profile: profile(),
      siteUrl: siteUrl(req),
      related: queries.projects().filter((p) => p.id !== project.id).slice(0, 2),
    })
  );
});

app.get("/resources", (req, res) => {
  res.send(
    render.resourcesPage({
      nonce: req.nonce,
      resources: queries.resources(),
      profile: profile(),
      siteUrl: siteUrl(req),
    })
  );
});

app.get("/resources/:slug", (req, res, next) => {
  const resource = queries.resourceBySlug(req.params.slug);
  if (!resource) return next();
  res.send(
    render.resourcePage({
      nonce: req.nonce,
      resource,
      profile: profile(),
      siteUrl: siteUrl(req),
      related: queries.resources().filter((r) => r.id !== resource.id).slice(0, 3),
    })
  );
});

app.get("/videos", (req, res) => {
  res.send(
    render.videosPage({
      nonce: req.nonce,
      videos: queries.videos(),
      profile: profile(),
      siteUrl: siteUrl(req),
    })
  );
});

app.get("/videos/:slug", (req, res, next) => {
  const video = queries.videoBySlug(req.params.slug);
  if (!video) return next();
  res.send(
    render.videoPage({
      nonce: req.nonce,
      video,
      profile: profile(),
      siteUrl: siteUrl(req),
      related: queries.videos().filter((v) => v.id !== video.id).slice(0, 3),
    })
  );
});

/* --------------------------------------------------------------- downloads + CV */
function sendResourceFile(res, resource, { asAttachment }) {
  const abs = resolveFile(resource.file_path);
  if (!abs) return res.status(404).send("File missing. Please contact Nasir.");
  db.prepare("UPDATE resources SET downloads = downloads + 1 WHERE id = ?").run(resource.id);
  const safeName = (resource.file_name || `${resource.slug}.pdf`).replace(/[^\w.\- ]+/g, "_");
  res.setHeader("Content-Type", resource.file_type || "application/pdf");
  res.setHeader(
    "Content-Disposition",
    `${asAttachment ? "attachment" : "inline"}; filename="${safeName}"`
  );
  res.setHeader("X-Content-Type-Options", "nosniff");
  fs.createReadStream(abs).pipe(res);
}

app.get("/download/:slug", (req, res, next) => {
  const resource = queries.resourceBySlug(req.params.slug);
  if (!resource) return next();
  sendResourceFile(res, resource, { asAttachment: true });
});

app.get("/view/:slug", (req, res, next) => {
  const resource = queries.resourceBySlug(req.params.slug);
  if (!resource) return next();
  sendResourceFile(res, resource, { asAttachment: false });
});

app.get("/cv", (req, res) => res.redirect(302, "/download-cv"));

/** "Download CV" button: always serves the resource marked as the CV. */
app.get("/download-cv", (req, res, next) => {
  const slug = profile().cvSlug || "nasir-hamid-cv";
  const resource = queries.resourceBySlug(slug);
  if (resource) return sendResourceFile(res, resource, { asAttachment: true });
  const fallback = path.join(PUBLIC_DIR, "cv", "nasir-hamid-cv.pdf");
  if (fs.existsSync(fallback)) return res.download(fallback, "Nasir-Hamid-CV.pdf");
  next();
});

/* ---------------------------------------------------------------- public API */
app.get("/api/site", (req, res) => {
  res.json({ profile: profile(), about: about(), skills: skills(), seo: seo() });
});

app.get("/healthz", (req, res) => {
  try {
    db.prepare("SELECT 1").get();
    res.json({ ok: true, uptime: Math.round(process.uptime()) });
  } catch (err) {
    res.status(503).json({ ok: false });
  }
});

app.get("/api/projects", (req, res) => res.json(queries.projects()));
app.get("/api/resources", (req, res) => res.json(queries.resources()));
app.get("/api/videos", (req, res) => res.json(queries.videos()));

/* contact form */
const contactHits = new Map();
app.post("/api/contact", (req, res) => {
  const ip = req.ip || "unknown";
  const now = Date.now();
  const rec = contactHits.get(ip);
  if (rec && now - rec.first < 60 * 60 * 1000 && rec.count >= 5) {
    return res.status(429).json({ error: "Too many messages from this connection. Please try later." });
  }
  contactHits.set(
    ip,
    rec && now - rec.first < 60 * 60 * 1000 ? { first: rec.first, count: rec.count + 1 } : { first: now, count: 1 }
  );

  const { name = "", email = "", subject = "", message = "", company = "" } = req.body || {};
  if (company) return res.json({ ok: true }); // honeypot tripped — silently ignore
  const clean = (v) => String(v).trim();
  const payload = {
    name: clean(name).slice(0, 80),
    email: clean(email).slice(0, 120),
    subject: clean(subject).slice(0, 120),
    message: clean(message).slice(0, 4000),
  };
  if (payload.name.length < 2) return res.status(400).json({ error: "Please enter your name." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(payload.email))
    return res.status(400).json({ error: "Please enter a valid email address." });
  if (payload.message.length < 10)
    return res.status(400).json({ error: "Your message is a little too short." });

  db.prepare("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)").run(
    payload.name,
    payload.email,
    payload.subject,
    payload.message
  );
  res.json({ ok: true, message: "Message sent. Thanks — I'll reply as soon as I can." });
});

/* ----------------------------------------------------------------- admin API */
const api = express.Router();
api.use(express.json({ limit: "400kb" }));
api.use(auth.requireSameOrigin);

api.post("/login", (req, res) => {
  const ip = req.ip || "unknown";
  if (auth.tooManyAttempts(ip))
    return res.status(429).json({ error: "Too many attempts. Try again in 15 minutes." });
  const email = String(req.body?.email || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  const admin = db.prepare("SELECT * FROM admins WHERE email = ?").get(email);
  if (!admin || !auth.verifyPassword(password, admin.pass_hash)) {
    auth.recordAttempt(ip);
    return res.status(401).json({ error: "Email or password is incorrect." });
  }
  auth.clearAttempts(ip);
  auth.createSession(res, admin.id);
  res.json({ ok: true, admin: { email: admin.email } });
});

api.post("/logout", (req, res) => {
  auth.destroySession(req, res);
  res.json({ ok: true });
});

api.get("/me", (req, res) => {
  const admin = auth.currentAdmin(req);
  if (!admin) return res.status(401).json({ error: "Not authenticated" });
  res.json({ admin });
});

api.use(auth.requireAuth);

api.get("/stats", (req, res) => {
  const one = (sql) => db.prepare(sql).get().c;
  res.json({
    projects: one("SELECT COUNT(*) c FROM projects"),
    projectsPublished: one("SELECT COUNT(*) c FROM projects WHERE published = 1"),
    resources: one("SELECT COUNT(*) c FROM resources"),
    resourcesPublished: one("SELECT COUNT(*) c FROM resources WHERE published = 1"),
    videos: one("SELECT COUNT(*) c FROM videos"),
    videosPublished: one("SELECT COUNT(*) c FROM videos WHERE published = 1"),
    messages: one("SELECT COUNT(*) c FROM messages"),
    unread: one("SELECT COUNT(*) c FROM messages WHERE is_read = 0"),
    downloads: db.prepare("SELECT COALESCE(SUM(downloads), 0) s FROM resources").get().s,
    storage: (() => {
      let total = 0;
      const walk = (dir) => {
        if (!fs.existsSync(dir)) return;
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
          const p = path.join(dir, entry.name);
          if (entry.isDirectory()) walk(p);
          else total += fs.statSync(p).size;
        }
      };
      walk(path.join(UPLOAD_DIR, "pdf"));
      return total;
    })(),
    limits: { maxPdf: MAX_PDF },
  });
});

/* ---- projects ---- */
api.get("/projects", (req, res) => res.json(queries.projects(true)));

api.post("/projects", uploadFields, (req, res) => {
  const files = validateFiles(req.files);
  if (files.error) {
    cleanup(req.files);
    return res.status(400).json({ error: files.error });
  }
  const { title = "", summary = "", description = "", tech = "", live_url = "", repo_url = "", featured, published } = req.body;
  if (String(title).trim().length < 3) {
    cleanup(req.files);
    return res.status(400).json({ error: "A title of at least 3 characters is required." });
  }
  const slug = uniqueSlug("projects", title);
  const info = db
    .prepare(
      `INSERT INTO projects (title, slug, summary, description, tech, thumb, live_url, repo_url, featured, published, sort)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      String(title).trim(),
      slug,
      String(summary).trim(),
      String(description).trim(),
      JSON.stringify(splitList(tech)),
      files.thumb?.url || null,
      String(live_url).trim() || null,
      String(repo_url).trim() || null,
      featured === "1" || featured === true ? 1 : 0,
      published === "0" || published === false ? 0 : 1,
      db.prepare("SELECT COALESCE(MAX(sort), 0) + 1 s FROM projects").get().s
    );
  res.status(201).json({ ok: true, id: info.lastInsertRowid, slug });
});

api.put("/projects/:id", uploadFields, (req, res) => {
  const existing = db.prepare("SELECT * FROM projects WHERE id = ?").get(req.params.id);
  if (!existing) {
    cleanup(req.files);
    return res.status(404).json({ error: "Project not found" });
  }
  const files = validateFiles(req.files);
  if (files.error) {
    cleanup(req.files);
    return res.status(400).json({ error: files.error });
  }
  const b = req.body;
  const title = String(b.title ?? existing.title).trim();
  if (title.length < 3) {
    cleanup(req.files);
    return res.status(400).json({ error: "A title of at least 3 characters is required." });
  }
  if (files.thumb && existing.thumb) removeThumb(existing.thumb);
  db.prepare(
    `UPDATE projects SET title=?, slug=?, summary=?, description=?, tech=?, thumb=?, live_url=?, repo_url=?,
     featured=?, published=?, updated_at=datetime('now') WHERE id=?`
  ).run(
    title,
    existing.title === title ? existing.slug : uniqueSlug("projects", title, existing.id),
    String(b.summary ?? existing.summary).trim(),
    String(b.description ?? existing.description).trim(),
    JSON.stringify(b.tech !== undefined ? splitList(b.tech) : JSON.parse(existing.tech || "[]")),
    files.thumb?.url || existing.thumb,
    b.live_url !== undefined ? String(b.live_url).trim() || null : existing.live_url,
    b.repo_url !== undefined ? String(b.repo_url).trim() || null : existing.repo_url,
    b.featured !== undefined ? (b.featured === "1" || b.featured === true ? 1 : 0) : existing.featured,
    b.published !== undefined ? (b.published === "1" || b.published === true ? 1 : 0) : existing.published,
    existing.id
  );
  res.json({ ok: true });
});

api.delete("/projects/:id", (req, res) => {
  const existing = db.prepare("SELECT * FROM projects WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Project not found" });
  if (existing.thumb) removeThumb(existing.thumb);
  db.prepare("DELETE FROM projects WHERE id = ?").run(existing.id);
  res.json({ ok: true });
});

/* ---- resources ---- */
api.get("/resources", (req, res) => res.json(queries.resources(true)));

api.post("/resources", uploadFields, (req, res) => {
  const files = validateFiles(req.files, { requirePdf: true });
  if (files.error) {
    cleanup(req.files);
    return res.status(400).json({ error: files.error });
  }
  const { title = "", description = "", category = "Documents", published } = req.body;
  if (String(title).trim().length < 3) {
    cleanup(req.files);
    return res.status(400).json({ error: "A resource title is required." });
  }
  const slug = uniqueSlug("resources", title);
  const info = db
    .prepare(
      `INSERT INTO resources (title, slug, description, category, file_path, file_name, file_size, file_type, thumb, published)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'application/pdf', ?, ?)`
    )
    .run(
      String(title).trim(),
      slug,
      String(description).trim(),
      String(category).trim() || "Documents",
      files.pdf.stored,
      String(req.files.file[0].originalname || `${slug}.pdf`).slice(0, 160),
      files.pdf.size,
      files.thumb?.url || null,
      published === "0" || published === false ? 0 : 1
    );
  res.status(201).json({ ok: true, id: info.lastInsertRowid, slug });
});

api.put("/resources/:id", uploadFields, (req, res) => {
  const existing = db.prepare("SELECT * FROM resources WHERE id = ?").get(req.params.id);
  if (!existing) {
    cleanup(req.files);
    return res.status(404).json({ error: "Resource not found" });
  }
  const files = validateFiles(req.files);
  if (files.error) {
    cleanup(req.files);
    return res.status(400).json({ error: files.error });
  }
  const b = req.body;
  const title = String(b.title ?? existing.title).trim();
  if (title.length < 3) {
    cleanup(req.files);
    return res.status(400).json({ error: "A resource title is required." });
  }
  if (files.pdf && existing.file_path) removeStored(existing.file_path);
  if (files.thumb && existing.thumb) removeThumb(existing.thumb);
  db.prepare(
    `UPDATE resources SET title=?, slug=?, description=?, category=?, file_path=?, file_name=?, file_size=?,
     thumb=?, published=?, updated_at=datetime('now') WHERE id=?`
  ).run(
    title,
    existing.title === title ? existing.slug : uniqueSlug("resources", title, existing.id),
    String(b.description ?? existing.description).trim(),
    String(b.category ?? existing.category).trim() || "Documents",
    files.pdf?.stored || existing.file_path,
    files.pdf ? String(req.files.file[0].originalname || existing.file_name).slice(0, 160) : existing.file_name,
    files.pdf?.size ?? existing.file_size,
    files.thumb?.url || existing.thumb,
    b.published !== undefined ? (b.published === "1" || b.published === true ? 1 : 0) : existing.published,
    existing.id
  );
  res.json({ ok: true });
});

api.delete("/resources/:id", (req, res) => {
  const existing = db.prepare("SELECT * FROM resources WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Resource not found" });
  removeStored(existing.file_path);
  if (existing.thumb) removeThumb(existing.thumb);
  db.prepare("DELETE FROM resources WHERE id = ?").run(existing.id);
  res.json({ ok: true });
});

/* ---- videos ---- */
api.get("/videos", (req, res) => res.json(queries.videos(true)));

function parseYouTubeId(input = "") {
  const value = String(input).trim();
  if (!value) return null;
  if (/^[A-Za-z0-9_-]{11}$/.test(value)) return value;
  const patterns = [
    /(?:youtube\.com\/watch\?[^#]*v=)([A-Za-z0-9_-]{11})/,
    /(?:youtu\.be\/)([A-Za-z0-9_-]{11})/,
    /(?:youtube\.com\/embed\/)([A-Za-z0-9_-]{11})/,
    /(?:youtube\.com\/shorts\/)([A-Za-z0-9_-]{11})/,
  ];
  for (const p of patterns) {
    const m = value.match(p);
    if (m) return m[1];
  }
  return null;
}

api.post("/videos", uploadFields, async (req, res) => {
  const files = validateFiles(req.files);
  if (files.error) {
    cleanup(req.files);
    return res.status(400).json({ error: files.error });
  }
  const { title = "", description = "", category = "Recommended", youtube = "", external_url = "", duration = "", published } = req.body;
  if (String(title).trim().length < 3) {
    cleanup(req.files);
    return res.status(400).json({ error: "A video title is required." });
  }
  const youtubeId = parseYouTubeId(youtube);
  if (String(youtube).trim() && !youtubeId) {
    cleanup(req.files);
    return res.status(400).json({ error: "That doesn't look like a valid YouTube link or ID." });
  }
  if (!youtubeId && !String(external_url).trim()) {
    cleanup(req.files);
    return res.status(400).json({ error: "Add a YouTube link, or an external video URL." });
  }
  const slug = uniqueSlug("videos", title);
  // Store the YouTube thumbnail locally (falls back to the remote URL if offline).
  const thumb =
    files.thumb?.url ||
    (youtubeId ? (await fetchYouTubeThumb(youtubeId)) || `https://i.ytimg.com/vi/${youtubeId}/hqdefault.jpg` : null);
  const info = db
    .prepare(
      `INSERT INTO videos (title, slug, description, category, youtube_id, external_url, thumb, duration, published)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      String(title).trim(),
      slug,
      String(description).trim(),
      String(category).trim() || "Recommended",
      youtubeId,
      String(external_url).trim() || null,
      thumb,
      String(duration).trim() || null,
      published === "0" || published === false ? 0 : 1
    );
  res.status(201).json({ ok: true, id: info.lastInsertRowid, slug });
});

api.put("/videos/:id", uploadFields, async (req, res) => {
  const existing = db.prepare("SELECT * FROM videos WHERE id = ?").get(req.params.id);
  if (!existing) {
    cleanup(req.files);
    return res.status(404).json({ error: "Video not found" });
  }
  const files = validateFiles(req.files);
  if (files.error) {
    cleanup(req.files);
    return res.status(400).json({ error: files.error });
  }
  const b = req.body;
  const title = String(b.title ?? existing.title).trim();
  const youtubeRaw = b.youtube !== undefined ? b.youtube : existing.youtube_id || "";
  const youtubeId = parseYouTubeId(youtubeRaw);
  if (String(youtubeRaw).trim() && !youtubeId) {
    cleanup(req.files);
    return res.status(400).json({ error: "That doesn't look like a valid YouTube link or ID." });
  }
  if (files.thumb && existing.thumb && existing.thumb.startsWith("/media/")) removeThumb(existing.thumb);
  let thumb = files.thumb?.url || existing.thumb;
  if (!thumb) thumb = (youtubeId ? await fetchYouTubeThumb(youtubeId) : null);
  db.prepare(
    `UPDATE videos SET title=?, slug=?, description=?, category=?, youtube_id=?, external_url=?, thumb=?, duration=?,
     published=?, updated_at=datetime('now') WHERE id=?`
  ).run(
    title,
    existing.title === title ? existing.slug : uniqueSlug("videos", title, existing.id),
    String(b.description ?? existing.description).trim(),
    String(b.category ?? existing.category).trim() || "Recommended",
    youtubeId,
    b.external_url !== undefined ? String(b.external_url).trim() || null : existing.external_url,
    thumb,
    b.duration !== undefined ? String(b.duration).trim() || null : existing.duration,
    b.published !== undefined ? (b.published === "1" || b.published === true ? 1 : 0) : existing.published,
    existing.id
  );
  res.json({ ok: true });
});

api.delete("/videos/:id", (req, res) => {
  const existing = db.prepare("SELECT * FROM videos WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Video not found" });
  if (existing.thumb) removeThumb(existing.thumb);
  db.prepare("DELETE FROM videos WHERE id = ?").run(existing.id);
  res.json({ ok: true });
});

/* ---- messages ---- */
api.get("/messages", (req, res) =>
  res.json(db.prepare("SELECT * FROM messages ORDER BY created_at DESC").all())
);
api.patch("/messages/:id", (req, res) => {
  db.prepare("UPDATE messages SET is_read = ? WHERE id = ?").run(
    req.body?.is_read ? 1 : 0,
    req.params.id
  );
  res.json({ ok: true });
});
api.delete("/messages/:id", (req, res) => {
  db.prepare("DELETE FROM messages WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

/* ---- site content (profile / about / skills / seo) ---- */
const CONTENT_KEYS = ["profile", "about", "skills", "seo"];
api.get("/content", (req, res) => {
  res.json({
    profile: profile(),
    about: about(),
    skills: skills(),
    seo: seo(),
  });
});

api.put("/content/:key", (req, res) => {
  const { key } = req.params;
  if (!CONTENT_KEYS.includes(key)) return res.status(400).json({ error: "Unknown content block" });
  const value = req.body;
  if (typeof value !== "object" || value === null || Array.isArray(value))
    return res.status(400).json({ error: "Invalid content payload" });
  // Merge so a partial update can never wipe the rest of the block.
  const existing = getSetting(key, {}) || {};
  setSetting(key, { ...existing, ...value });
  res.json({ ok: true });
});

api.post("/password", (req, res) => {
  const { current, next } = req.body || {};
  const admin = db.prepare("SELECT * FROM admins WHERE id = ?").get(req.admin.id);
  if (!auth.verifyPassword(String(current || ""), admin.pass_hash))
    return res.status(400).json({ error: "Current password is incorrect." });
  const pw = String(next || "");
  if (pw.length < 10) return res.status(400).json({ error: "Use at least 10 characters." });
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw))
    return res.status(400).json({ error: "Mix letters and numbers for a stronger password." });
  db.prepare("UPDATE admins SET pass_hash = ? WHERE id = ?").run(auth.hashPassword(pw), admin.id);
  // Invalidate every other session.
  db.prepare("DELETE FROM sessions WHERE admin_id = ?").run(admin.id);
  auth.createSession(res, admin.id);
  res.json({ ok: true });
});

app.use("/api/admin", api);

/* --------------------------------------------------------------- admin dashboard */
app.get(["/admin", "/admin/"], (req, res) => {
  res.setHeader("X-Robots-Tag", "noindex, nofollow");
  res.sendFile(path.join(PUBLIC_DIR, "admin.html"));
});

/* --------------------------------------------------------------------- errors */
app.use((req, res) => {
  res
    .status(404)
    .send(
      render.notFoundPage({ nonce: req.nonce, profile: profile(), siteUrl: siteUrl(req) })
    );
});

app.use((err, req, res, next) => {
  if (err?.message?.includes("Only PDF") || err?.message?.includes("Thumbnails") || err?.code === "LIMIT_FILE_SIZE") {
    return res.status(400).json({
      error:
        err.code === "LIMIT_FILE_SIZE"
          ? "That file is too large. Maximum size is 25 MB."
          : err.message,
    });
  }
  console.error(err);
  if (req.path.startsWith("/api/")) return res.status(500).json({ error: "Server error" });
  res.status(500).send("Something went wrong.");
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Nasir Hamid portfolio running on http://localhost:${PORT}`);
  if (!PROD) console.log("Admin dashboard: /admin");
});

function splitList(value) {
  if (Array.isArray(value)) return value.map((v) => String(v).trim()).filter(Boolean);
  return String(value || "")
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean);
}
