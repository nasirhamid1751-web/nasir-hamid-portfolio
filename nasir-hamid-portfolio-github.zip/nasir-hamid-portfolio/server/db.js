/**
 * SQLite data layer.
 * Single-file database (data/portfolio.db) — zero configuration, easy to back up.
 */
const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3");
const seed = require("./content-seed");

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "..", "data");
const DB_PATH = path.join(DATA_DIR, "portfolio.db");
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS admins (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  email       TEXT UNIQUE NOT NULL,
  pass_hash   TEXT NOT NULL,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash  TEXT PRIMARY KEY,
  admin_id    INTEGER NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  expires_at  INTEGER NOT NULL,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS projects (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT NOT NULL,
  slug        TEXT UNIQUE NOT NULL,
  summary     TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  tech        TEXT NOT NULL DEFAULT '[]',
  thumb       TEXT,
  live_url    TEXT,
  repo_url    TEXT,
  featured    INTEGER NOT NULL DEFAULT 0,
  published   INTEGER NOT NULL DEFAULT 1,
  sort        INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS resources (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT NOT NULL,
  slug        TEXT UNIQUE NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  category    TEXT NOT NULL DEFAULT 'Documents',
  file_path   TEXT NOT NULL,
  file_name   TEXT NOT NULL,
  file_size   INTEGER NOT NULL DEFAULT 0,
  file_type   TEXT NOT NULL DEFAULT 'application/pdf',
  thumb       TEXT,
  downloads   INTEGER NOT NULL DEFAULT 0,
  published   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS videos (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT NOT NULL,
  slug        TEXT UNIQUE NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  category    TEXT NOT NULL DEFAULT 'Recommended',
  youtube_id  TEXT,
  external_url TEXT,
  thumb       TEXT,
  duration    TEXT,
  featured    INTEGER NOT NULL DEFAULT 0,
  published   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS messages (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  email       TEXT NOT NULL,
  subject     TEXT NOT NULL DEFAULT '',
  message     TEXT NOT NULL,
  is_read     INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_projects_pub ON projects(published, sort);
CREATE INDEX IF NOT EXISTS idx_resources_pub ON resources(published, created_at);
CREATE INDEX IF NOT EXISTS idx_videos_pub ON videos(published, created_at);
`);

/* ------------------------------------------------------------------ settings */
const getSetting = (key, fallback = null) => {
  const row = db.prepare("SELECT value FROM settings WHERE key = ?").get(key);
  if (!row) return fallback;
  try {
    return JSON.parse(row.value);
  } catch {
    return fallback;
  }
};

const setSetting = (key, value) =>
  db
    .prepare(
      "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value"
    )
    .run(key, JSON.stringify(value));

/* --------------------------------------------------------------------- seeds */
function seedSettings() {
  const defaults = {
    profile: seed.profile,
    about: seed.about,
    skills: seed.skills,
    seo: seed.seo,
  };
  for (const [key, value] of Object.entries(defaults)) {
    if (!getSetting(key)) setSetting(key, value);
  }
}

function seedProjects() {
  const count = db.prepare("SELECT COUNT(*) c FROM projects").get().c;
  if (count > 0) return;
  const insert = db.prepare(`
    INSERT INTO projects (title, slug, summary, description, tech, thumb, live_url, repo_url, featured, published, sort)
    VALUES (@title, @slug, @summary, @description, @tech, @thumb, @live_url, @repo_url, @featured, @published, @sort)`);

  insert.run({
    title: "Personal Portfolio — v1",
    slug: "personal-portfolio-v1",
    summary:
      "My first personal website: a dark, terminal-inspired single page built to introduce myself and document the start of my learning journey.",
    description:
      "This was the project that turned me from a reader into a builder. I planned the sections, wrote the copy, and learned how HTML structure, CSS layout and small amounts of JavaScript fit together to make a complete page.\n\nBuilding it taught me how much detail sits behind a page that simply feels right — spacing, type scale, colour contrast, and the fact that every section has to work on a phone as well as a laptop.",
    tech: JSON.stringify(["HTML", "CSS", "JavaScript", "GitHub Pages"]),
    thumb: "/images/project-portfolio-v1-1200.jpg",
    live_url: "https://nasirhamid1751-web.github.io/Nasir-Portfolio/",
    repo_url: "https://github.com/nasirhamid1751-web/Nasir-Portfolio",
    featured: 1,
    published: 1,
    sort: 1,
  });

  insert.run({
    title: "Portfolio & Resource Hub — v2",
    slug: "portfolio-resource-hub-v2",
    summary:
      "The site you are reading now: a server-rendered portfolio with its own admin dashboard, PDF library and video section.",
    description:
      "Version two goes beyond a static page. Content lives in a database instead of hand-written HTML, so projects, PDF notes and videos can be published from a private dashboard without touching code.\n\nIt is also where I practise the parts of the web I find most interesting: server-side rendering for fast pages, file upload validation, sessions and authentication, and accessible responsive layout.",
    tech: JSON.stringify(["Node.js", "Express", "SQLite", "HTML", "CSS"]),
    thumb: "/images/workspace-1200.jpg",
    live_url: "/",
    repo_url: null,
    featured: 0,
    published: 1,
    sort: 2,
  });
}

function seedResources() {
  const count = db.prepare("SELECT COUNT(*) c FROM resources").get().c;
  if (count > 0) return;
  const cv = path.join(__dirname, "..", "public", "cv", "nasir-hamid-cv.pdf");
  if (!fs.existsSync(cv)) return;
  const stat = fs.statSync(cv);
  db.prepare(`
    INSERT INTO resources (title, slug, description, category, file_path, file_name, file_size, file_type, published)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)`).run(
    "Nasir Hamid — CV",
    "nasir-hamid-cv",
    "A one-page overview of my education, areas of focus, interests and vision. Updated whenever something meaningful changes.",
    "Documents",
    "public/cv/nasir-hamid-cv.pdf",
    "Nasir-Hamid-CV.pdf",
    stat.size,
    "application/pdf"
  );
}

function seedVideos() {
  const count = db.prepare("SELECT COUNT(*) c FROM videos").get().c;
  if (count > 0) return;
  const insert = db.prepare(`
    INSERT INTO videos (title, slug, description, category, youtube_id, thumb, duration, featured, published)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)`);

  insert.run(
    "CS50x 2024 — Lecture 0: Scratch",
    "cs50x-2024-lecture-0",
    "The lecture that made computer science click for me. Harvard's CS50 starts at the very beginning — no assumptions, no shortcuts — which is exactly the approach I'm trying to take with my own learning.",
    "Recommended watching",
    "3LPJfIKxwWc",
    "/images/video-cs50-lecture0.jpg",
    "1h 48m",
    1
  );

  insert.run(
    "CS50x 2024 — Lecture 1: C",
    "cs50x-2024-lecture-1",
    "Moving from Scratch blocks to real code. This is where the ideas behind variables, loops, conditions and compiling stopped being abstract for me.",
    "Recommended watching",
    "cwtpLIWylAw",
    "/images/video-cs50-lecture1.jpg",
    "1h 57m",
    0
  );

  insert.run(
    "CS50x 2024 — Lecture 2: Arrays",
    "cs50x-2024-lecture-2",
    "The lecture I keep coming back to. Arrays, strings and memory explained slowly enough that a Grade 10 student can actually follow along.",
    "Recommended watching",
    "4vU4aEFmTSo",
    "/images/video-cs50-lecture2.jpg",
    "2h 06m",
    0
  );
}

function init() {
  seedSettings();
  seedProjects();
  seedResources();
  seedVideos();
}

/* ------------------------------------------------------------------- helpers */
const slugify = (str) =>
  String(str)
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^\w\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 80) || "item";

function uniqueSlug(table, base, ignoreId = null) {
  let slug = slugify(base);
  let candidate = slug;
  let i = 2;
  const stmt = db.prepare(`SELECT id FROM ${table} WHERE slug = ?`);
  for (;;) {
    const row = stmt.get(candidate);
    if (!row || row.id === ignoreId) return candidate;
    candidate = `${slug}-${i++}`;
  }
}

module.exports = {
  db,
  DATA_DIR,
  DB_PATH,
  UPLOAD_DIR,
  getSetting,
  setSetting,
  init,
  slugify,
  uniqueSlug,
};
