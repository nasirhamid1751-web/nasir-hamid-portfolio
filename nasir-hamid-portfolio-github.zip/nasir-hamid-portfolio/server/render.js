/**
 * Server-side rendering: every public page is real HTML on first byte
 * (fast paint, crawlable, works without JavaScript).
 */
const ICONS = {
  "arrow-up-right": '<path d="M7 17 17 7M9 7h8v8"/>',
  "arrow-down": '<path d="M12 5v14M6 13l6 6 6-6"/>',
  "arrow-right": '<path d="M5 12h14M13 6l6 6-6 6"/>',
  download: '<path d="M12 3v12M7 11l5 5 5-5M5 21h14"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m4 7 8 6 8-6"/>',
  phone:
    '<path d="M6.5 3h3l1.5 4-2 1.5a12 12 0 0 0 6.5 6.5L17 13l4 1.5v3a2 2 0 0 1-2.2 2A17 17 0 0 1 4 5.2 2 2 0 0 1 6.5 3Z"/>',
  github:
    '<path d="M9 19c-4 1.2-4-2.2-5.6-2.6M15 21v-3.4c0-1 .1-1.4-.5-2 2.3-.3 4.5-1.2 4.5-5.2a4 4 0 0 0-1.1-2.8 3.7 3.7 0 0 0-.1-2.8s-1.1-.3-3.4 1.3a8.6 8.6 0 0 0-4.4 0C7.7 4.5 6.6 4.8 6.6 4.8a3.7 3.7 0 0 0-.1 2.8A4 4 0 0 0 5.4 10c0 4 2.2 4.9 4.5 5.2-.5.6-.5 1.2-.5 2V21"/>',
  play: '<path d="M8 5.5v13l11-6.5Z"/>',
  code: '<path d="m8 8-5 4 5 4M16 8l5 4-5 4M14 4l-4 16"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M10 2v3M14 2v3M10 19v3M14 19v3M2 10h3M2 14h3M19 10h3M19 14h3"/>',
  js: '<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M10 10v5a2 2 0 0 1-2 2M14.5 16.5c.6.7 3 .9 3-.9 0-1.6-2.8-1.3-2.8-3 0-1.6 2.1-1.6 2.7-.9"/>',
  book: '<path d="M4 5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2Z"/><path d="M8 3v18"/>',
  brain:
    '<path d="M12 5a3 3 0 0 0-6 0 3 3 0 0 0-1 5.8A3 3 0 0 0 6.5 17 3 3 0 0 0 12 19Zm0 0a3 3 0 0 1 6 0 3 3 0 0 1 1 5.8A3 3 0 0 1 17.5 17 3 3 0 0 1 12 19Z"/>',
  lang: '<path d="M3 5h11M8.5 5v2c0 4-2.5 7-5.5 8M6 11c1.5 2.5 4 4.5 6 5"/><path d="m12.5 21 4-11 4 11M14 17.5h5"/>',
  "file-text": '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4M16 3v4M3 11h18"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  check: '<path d="m5 13 4 4L19 7"/>',
  spark: '<path d="M12 3.2l1.7 4.6 4.6 1.7-4.6 1.7L12 15.8l-1.7-4.6L5.7 9.5l4.6-1.7Z"/><path d="M18.5 15.5l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8Z"/>',
  external: '<path d="M14 4h6v6M20 4 11 13M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6Z"/><path d="m9 12 2 2 4-4"/>',
  quote:
    '<path d="M9.6 6.5C6.9 7.7 5.5 9.9 5.5 12.6V18h5.6v-5.6H8.4c0-1.9.7-3.2 2.5-4.2l-1.3-1.7Zm9 0c-2.7 1.2-4.1 3.4-4.1 6.1V18h5.6v-5.6h-2.7c0-1.9.7-3.2 2.5-4.2l-1.3-1.7Z"/>',
  layers2: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  "arrow-left": '<path d="M19 12H5M11 6l-6 6 6 6"/>',
};

const icon = (name, cls = "") =>
  `<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><use href="#i-${name}"/></svg>`;

const sprite = () =>
  `<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">${Object.entries(
    ICONS
  )
    .map(([k, v]) => `<symbol id="i-${k}" viewBox="0 0 24 24">${v}</symbol>`)
    .join("")}</svg>`;

const esc = (s = "") =>
  String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");

const paragraphs = (arr = []) =>
  (Array.isArray(arr) ? arr : []).filter(Boolean).map((p) => `<p>${esc(p)}</p>`).join("");

/** Splits a textarea-style description ("para\n\npara") into paragraphs. */
const textParagraphs = (text = "") =>
  String(text)
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter(Boolean)
    .map((p) => `<p>${esc(p).replace(/\n/g, "<br>")}</p>`)
    .join("");

const fileSize = (bytes) => {
  if (!bytes) return "—";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let n = bytes;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i += 1;
  }
  return `${n >= 10 || i === 0 ? Math.round(n) : n.toFixed(1)} ${units[i]}`;
};

const dateLabel = (iso) => {
  if (!iso) return "";
  const d = new Date(iso.includes("T") ? iso : iso.replace(" ", "T") + "Z");
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
};

const NAV = [
  ["Home", "/"],
  ["About Me", "/#about"],
  ["Skills", "/#skills"],
  ["Projects", "/projects"],
  ["Resources", "/resources"],
  ["Videos", "/videos"],
  ["Contact", "/#contact"],
];

/* ------------------------------------------------------------------- chrome */
function navBar(profile, active = "") {
  return `
<a class="skip-link" href="#main">Skip to content</a>
${sprite()}
<div class="scroll-progress" id="scrollProgress"></div>
<header class="nav" id="nav">
  <div class="container nav__inner">
    <a class="brand" href="/" aria-label="Nasir Hamid — home">
      <span class="brand__mark">NH</span>
      <span class="brand__text">Nasir Hamid<em>student · builder</em></span>
    </a>
    <nav class="nav__links" id="navLinks" aria-label="Primary">
      ${NAV.map(
        ([label, href]) =>
          `<a href="${href}"${active === label ? ' aria-current="page"' : ""}>${label}</a>`
      ).join("")}
    </nav>
    <div class="nav__actions">
      <a class="btn btn--primary btn--sm" href="/#contact">Let's talk ${icon("arrow-up-right")}</a>
      <button class="nav__toggle" id="navToggle" aria-expanded="false" aria-controls="mobileMenu" aria-label="Open menu">
        <span></span><span></span>
      </button>
    </div>
  </div>
</header>
<div class="mobile-menu" id="mobileMenu" hidden>
  <nav aria-label="Mobile">
    ${NAV.map(([label, href], i) => `<a href="${href}" style="--d:${i * 45}ms">${label}</a>`).join("")}
  </nav>
  <div class="mobile-menu__foot">
    <a href="mailto:${esc(profile.email)}">${esc(profile.email)}</a>
    <a href="/admin" class="mobile-menu__admin">Admin</a>
  </div>
</div>`;
}

function footer(profile) {
  return `
<footer class="footer">
  <div class="container">
    <div class="footer__cta">
      <p class="footer__kicker">Available for learning opportunities</p>
      <h2 class="footer__title">Let's build something<span class="accent">.</span></h2>
      <a class="btn btn--primary btn--lg" href="/#contact">Get in touch ${icon("arrow-up-right")}</a>
    </div>
    <div class="footer__grid">
      <div>
        <a class="brand brand--footer" href="/">
          <span class="brand__mark">NH</span>
          <span class="brand__text">Nasir Hamid<em>student · builder</em></span>
        </a>
        <p class="footer__note">Grade 10 student learning computer science in public — documenting projects, notes and progress.</p>
      </div>
      <nav class="footer__col" aria-label="Sections">
        <h3>Explore</h3>
        ${NAV.slice(1, 6).map(([l, h]) => `<a href="${h}">${l}</a>`).join("")}
      </nav>
      <div class="footer__col">
        <h3>Elsewhere</h3>
        <a href="mailto:${esc(profile.email)}">Email ${icon("arrow-up-right")}</a>
        <a href="${esc(profile.github)}" target="_blank" rel="noopener">GitHub ${icon("arrow-up-right")}</a>
        <a href="${esc(profile.website)}" target="_blank" rel="noopener">Old site ${icon("arrow-up-right")}</a>
        <a href="/admin">Admin login</a>
      </div>
    </div>
    <div class="footer__bottom">
      <p>© ${new Date().getFullYear()} Nasir Hamid. Built and maintained by me.</p>
      <a href="#home" class="footer__top">Back to top ${icon("arrow-up")}</a>
    </div>
  </div>
</footer>
<button class="to-top" id="toTop" aria-label="Back to top" hidden>${icon("arrow-up-right")}</button>`;
}

function layout({
  nonce,
  title,
  description,
  canonical,
  ogImage = "/images/og-image.jpg",
  profile,
  body,
  active = "",
  jsonLd = null,
  robots = "index,follow",
  pageClass = "",
}) {
  const origin = (() => {
    try {
      return new URL(canonical).origin;
    } catch {
      return "";
    }
  })();
  const ogAbs = ogImage.startsWith("http") ? ogImage : `${origin}${ogImage}`;
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(title)}</title>
<meta name="description" content="${esc(description)}">
<meta name="author" content="Nasir Hamid">
<meta name="robots" content="${robots}">
<link rel="canonical" href="${esc(canonical)}">
<meta name="theme-color" content="#0B0D0C">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Nasir Hamid">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(description)}">
<meta property="og:url" content="${esc(canonical)}">
<meta property="og:image" content="${esc(ogAbs)}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:locale" content="en_GB">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${esc(title)}">
<meta name="twitter:description" content="${esc(description)}">
<meta name="twitter:image" content="${esc(ogAbs)}">
<link rel="icon" href="/images/favicon.ico" sizes="any">
<link rel="icon" type="image/png" href="/images/favicon-32.png" sizes="32x32">
<link rel="apple-touch-icon" href="/images/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<link rel="preload" href="/fonts/archivo-latin.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="/fonts/inter-latin.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="/fonts/fonts.css">
<link rel="stylesheet" href="/css/site.css">
<script nonce="${nonce}">document.documentElement.className+=" js";</script>
${jsonLd ? `<script type="application/ld+json" nonce="${nonce}">${JSON.stringify(jsonLd)}</script>` : ""}
</head>
<body class="${pageClass}">
${navBar(profile, active)}
<main id="main">
${body}
</main>
${footer(profile)}
<script src="/js/site.js" defer></script>
</body>
</html>`;
}

/* ------------------------------------------------------------------- sections */
function hero(profile) {
  return `
<section class="hero" id="home">
  <div class="hero__grid-bg" aria-hidden="true"></div>
  <div class="container hero__inner">
    <div class="hero__copy">
      <span class="pill reveal"><span class="dot"></span>${esc(profile.eyebrow)}</span>
      <h1 class="hero__title reveal" style="--d:60ms">
        <span>${esc(profile.headlineLine1)}</span>
        <span>${esc(profile.headlineLine2)}<span class="accent">.</span></span>
      </h1>
      <p class="hero__lead reveal" style="--d:120ms">${esc(profile.tagline)}</p>
      <p class="hero__intro reveal" style="--d:160ms">${esc(profile.intro)}</p>
      <div class="hero__actions reveal" style="--d:200ms">
        <a class="btn btn--primary btn--lg" href="#projects">Explore my work ${icon("arrow-down")}</a>
        <a class="btn btn--ghost btn--lg" href="/cv">Download CV ${icon("download")}</a>
      </div>
    </div>
    <div class="hero__visual reveal" style="--d:150ms">
      <div class="portrait">
        <picture>
          <source type="image/webp" srcset="/images/hero-portrait-640.webp 640w, /images/hero-portrait-900.webp 900w, /images/hero-portrait-1200.webp 1200w" sizes="(max-width: 900px) 88vw, 44vw">
          <img src="/images/hero-portrait-900.jpg" srcset="/images/hero-portrait-640.jpg 640w, /images/hero-portrait-900.jpg 900w, /images/hero-portrait-1200.jpg 1200w" sizes="(max-width: 900px) 88vw, 44vw" width="900" height="1125" alt="Nasir Hamid" fetchpriority="high" decoding="async">
        </picture>
        <span class="portrait__badge"><span class="dot"></span> status: learning</span>
      </div>
      <div class="hero__chip hero__chip--a">${icon("code")} self-taught</div>
      <div class="hero__chip hero__chip--b">${icon("book")} ${esc(profile.status)}</div>
    </div>
    <dl class="hero__facts reveal" style="--d:260ms">
      ${(profile.facts || [])
        .map((f) => `<div><dt>${esc(f.label)}</dt><dd>${esc(f.value)}</dd></div>`)
        .join("")}
    </dl>
  </div>
</section>
<div class="ticker" aria-hidden="true">
  <div class="ticker__track">
    ${["Curious", "Self-taught", "Consistent", "Computer science", "Grade 10", "Always learning", "Code · Build · Repeat"]
      .map((w) => `<span>${w}<i>✳</i></span>`)
      .join("")}
    ${["Curious", "Self-taught", "Consistent", "Computer science", "Grade 10", "Always learning", "Code · Build · Repeat"]
      .map((w) => `<span>${w}<i>✳</i></span>`)
      .join("")}
  </div>
</div>`;
}

function aboutSection(about, profile) {
  return `
<section class="section section--paper" id="about">
  <div class="container">
    <div class="section-head reveal">
      <p class="eyebrow"><span class="dot"></span>About me</p>
      <h2 class="display">Honest about where<br>I am — and where<br>I'm <span class="hl">going</span>.</h2>
    </div>
    <div class="about__lead reveal">
      <p>${esc(about.lead)}</p>
    </div>
    <div class="about__split">
      <div class="about__media reveal">
        <picture>
          <source type="image/webp" srcset="/images/about-portrait-560.webp 560w, /images/about-portrait-840.webp 840w" sizes="(max-width: 900px) 80vw, 34vw">
          <img src="/images/about-portrait-560.jpg" width="560" height="700" loading="lazy" decoding="async" alt="Portrait of Nasir Hamid">
        </picture>
        <div class="about__media-tag">
          <strong>Nasir Hamid</strong>
          <span>Grade 10 · computer science</span>
        </div>
      </div>
      <div class="about__body reveal" style="--d:80ms">
        ${paragraphs(about.paragraphs)}
        <ul class="chips" aria-label="Interests">
          ${(about.interests || []).map((i) => `<li>${esc(i)}</li>`).join("")}
        </ul>
        <div class="about__actions">
          <a class="btn btn--dark" href="/#contact">Say hello ${icon("arrow-up-right")}</a>
          <a class="link-arrow" href="/resources">Browse my resources ${icon("arrow-right")}</a>
        </div>
      </div>
    </div>

    <div class="journey">
      <div class="journey__head reveal">
        <p class="eyebrow"><span class="dot"></span>The pipeline</p>
        <h3 class="h2">My educational journey</h3>
      </div>
      <ol class="journey__list">
        ${(about.timeline || [])
          .map(
            (t, i) => `
        <li class="journey__item reveal" style="--d:${i * 70}ms">
          <span class="journey__step">${esc(t.step)}</span>
          <span class="journey__tag">${esc(t.tag)}</span>
          <h4>${esc(t.title)}</h4>
          <p>${esc(t.desc)}</p>
        </li>`
          )
          .join("")}
      </ol>
    </div>
  </div>
</section>`;
}

function skillsSection(skills) {
  return `
<section class="section section--ink" id="skills">
  <div class="container">
    <div class="section-head section-head--light reveal">
      <p class="eyebrow"><span class="dot"></span>Skills</p>
      <h2 class="display">What I'm<br><span class="hl">actually</span> learning</h2>
      <p class="section-head__note">${esc(skills.intro)}</p>
    </div>
    <div class="skills">
      ${(skills.groups || [])
        .map(
          (s, i) => `
      <article class="skill reveal" style="--d:${i * 60}ms">
        <span class="skill__icon">${icon(s.icon)}</span>
        <h3>${esc(s.title)}</h3>
        <p>${esc(s.desc)}</p>
        <span class="skill__level">${esc(s.level)}</span>
      </article>`
        )
        .join("")}
    </div>
    <p class="skills__foot reveal">${icon("shield")} Every level above is written honestly — no invented expertise. What I don't know yet, I'm working on.</p>
  </div>
</section>`;
}

function projectCard(p, wide = false) {
  const tech = Array.isArray(p.tech) ? p.tech : [];
  return `
<article class="pcard reveal${wide ? " pcard--wide" : ""}">
  <a class="pcard__media" href="/projects/${esc(p.slug)}" aria-label="${esc(p.title)} — view project">
    ${
      p.thumb
        ? `<img src="${esc(p.thumb)}" alt="Preview of ${esc(p.title)}" loading="lazy" decoding="async" width="1200" height="750">`
        : `<span class="pcard__media-fallback">${icon("code")}</span>`
    }
    <span class="pcard__view">${icon("arrow-up-right")}</span>
  </a>
  <div class="pcard__body">
    <div class="pcard__top">
      <h3><a href="/projects/${esc(p.slug)}">${esc(p.title)}</a></h3>
      ${p.featured ? `<span class="tag tag--mint">Featured</span>` : ""}
    </div>
    <p>${esc(p.summary)}</p>
    ${
      tech.length
        ? `<ul class="chips chips--sm">${tech.map((t) => `<li>${esc(t)}</li>`).join("")}</ul>`
        : ""
    }
    <div class="pcard__actions">
      ${p.live_url ? `<a class="btn btn--sm btn--dark" href="${esc(p.live_url)}" target="_blank" rel="noopener">Live project ${icon("arrow-up-right")}</a>` : ""}
      ${p.repo_url ? `<a class="btn btn--sm btn--ghost" href="${esc(p.repo_url)}" target="_blank" rel="noopener">${icon("github")} Source code</a>` : ""}
      <a class="link-arrow" href="/projects/${esc(p.slug)}">Details ${icon("arrow-right")}</a>
    </div>
  </div>
</article>`;
}

/** First project is a full-width feature; if the remaining count is odd the last card also spans full width. */
function projectFlags(list) {
  const flags = list.map((_, i) => i === 0);
  if (list.length > 1 && (list.length - 1) % 2 === 1) flags[list.length - 1] = true;
  return flags;
}

function projectsSection(projects) {
  const list = projects.filter((p) => p.published);
  return `
<section class="section section--paper" id="projects">
  <div class="container">
    <div class="section-head reveal">
      <p class="eyebrow"><span class="dot"></span>Projects</p>
      <h2 class="display">Things I've<br>built so <span class="hl">far</span></h2>
      <p class="section-head__note">Small in number, real in effort — each one taught me something specific.</p>
    </div>
    ${
      list.length
        ? `<div class="pgrid">${(() => {
            const flags = projectFlags(list);
            return list.map((p, i) => projectCard(p, flags[i])).join("");
          })()}</div>`
        : `<div class="empty">${icon("code")}<h3>First project incoming</h3><p>I'm building something worth showing. Check back soon.</p></div>`
    }
    <div class="section-foot reveal">
      <a class="btn btn--primary btn--lg" href="/projects">View all projects ${icon("arrow-right")}</a>
    </div>
  </div>
</section>`;
}

const CATEGORY_ICON = {
  Documents: "file-text",
  Notes: "book",
  Presentations: "layers2",
  Guides: "book",
  Books: "book",
  default: "file-text",
};

function resourceCard(r) {
  const ext = (r.file_name || "PDF").split(".").pop().toUpperCase();
  return `
<article class="rcard reveal" data-category="${esc(r.category)}">
  <div class="rcard__cover">
    ${
      r.thumb
        ? `<img src="${esc(r.thumb)}" alt="${esc(r.title)} preview" loading="lazy" decoding="async">`
        : `<span class="rcard__ext">${esc(ext)}</span><span class="rcard__lines" aria-hidden="true"><i></i><i></i><i></i><i></i></span>`
    }
    <span class="rcard__cat">${icon(CATEGORY_ICON[r.category] || CATEGORY_ICON.default)} ${esc(r.category)}</span>
  </div>
  <div class="rcard__body">
    <h3><a href="/resources/${esc(r.slug)}">${esc(r.title)}</a></h3>
    <p>${esc(r.description)}</p>
    <ul class="rmeta">
      <li>${icon("file-text")} ${esc(ext)} · ${fileSize(r.file_size)}</li>
      <li>${icon("calendar")} ${dateLabel(r.created_at)}</li>
      <li>${icon("download")} ${r.downloads} download${r.downloads === 1 ? "" : "s"}</li>
    </ul>
    <div class="rcard__actions">
      <a class="btn btn--sm btn--primary" href="/download/${esc(r.slug)}">Download ${icon("download")}</a>
      <a class="link-arrow" href="/resources/${esc(r.slug)}">Preview ${icon("arrow-right")}</a>
    </div>
  </div>
</article>`;
}

const promoCard = () => `
<article class="rcard rcard--promo reveal" data-category="__promo">
  <div class="rcard__cover rcard__cover--promo">
    <span class="rcard__promo-icon">${icon("spark")}</span>
  </div>
  <div class="rcard__body">
    <h3>Looking for something specific?</h3>
    <p>Tell me which topic you're studying and I'll add notes to the library if I have them — or point you to a source that helped me.</p>
    <div class="rcard__actions">
      <a class="link-arrow" href="/#contact">Request a resource ${icon("arrow-right")}</a>
    </div>
  </div>
</article>`;

function resourcesSection(resources) {
  const list = resources.filter((r) => r.published);
  const cats = ["All", ...new Set(list.map((r) => r.category))];
  return `
<section class="section section--ink" id="resources">
  <div class="container">
    <div class="section-head section-head--light reveal">
      <p class="eyebrow"><span class="dot"></span>Resources</p>
      <h2 class="display">Notes &amp;<br>files worth <span class="hl">sharing</span></h2>
      <p class="section-head__note">Documents, study notes and guides I'm allowed to pass on. Download them, use them, learn from them.</p>
    </div>
    ${
      list.length
        ? `<div class="filter" role="tablist" aria-label="Filter resources by category">
            ${cats
              .map(
                (c, i) =>
                  `<button class="filter__btn${i === 0 ? " is-active" : ""}" role="tab" aria-selected="${i === 0}" data-filter="${esc(c)}">${esc(c)}</button>`
              )
              .join("")}
          </div>
          <div class="rgrid" id="resourceGrid">${list.map(resourceCard).join("")}${promoCard()}</div>
          <p class="rgrid__empty" id="resourceEmpty" hidden>Nothing published in this category yet.</p>`
        : `<div class="empty empty--dark">${icon("file-text")}<h3>The library is being filled</h3><p>My CV is on its way here, followed by study notes. Check back soon.</p><a class="btn btn--primary" href="/resources">Open the resource library ${icon("arrow-right")}</a></div>`
    }
    <div class="section-foot reveal">
      <a class="btn btn--ghost btn--lg" href="/resources">All resources ${icon("arrow-right")}</a>
    </div>
  </div>
</section>`;
}

function videoCard(v) {
  return `
<article class="vcard reveal">
  <button class="vcard__media" data-video="${esc(v.youtube_id || "")}" data-title="${esc(v.title)}" aria-label="Play ${esc(v.title)}">
    ${
      v.thumb
        ? `<img src="${esc(v.thumb)}" alt="${esc(v.title)} thumbnail" loading="lazy" decoding="async">`
        : `<span class="vcard__fallback">${icon("play")}</span>`
    }
    <span class="vcard__play">${icon("play")}</span>
    ${v.duration ? `<span class="vcard__dur">${esc(v.duration)}</span>` : ""}
  </button>
  <div class="vcard__body">
    <span class="tag">${esc(v.category)}</span>
    <h3><a href="/videos/${esc(v.slug)}">${esc(v.title)}</a></h3>
    <p>${esc(v.description)}</p>
    <div class="vcard__actions">
      ${
        v.youtube_id
          ? `<button class="link-arrow" data-video="${esc(v.youtube_id)}" data-title="${esc(v.title)}">Watch here ${icon("play")}</button>`
          : ""
      }
      ${
        v.external_url
          ? `<a class="link-arrow" href="${esc(v.external_url)}" target="_blank" rel="noopener">External link ${icon("arrow-up-right")}</a>`
          : ""
      }
      <a class="link-arrow" href="/videos/${esc(v.slug)}">Details ${icon("arrow-right")}</a>
    </div>
  </div>
</article>`;
}

function videosSection(videos) {
  const list = videos.filter((v) => v.published).slice(0, 3);
  return `
<section class="section section--paper" id="videos">
  <div class="container">
    <div class="section-head reveal">
      <p class="eyebrow"><span class="dot"></span>Videos</p>
      <h2 class="display">Watch,<br>then <span class="hl">build</span></h2>
      <p class="section-head__note">What I'm publishing and what I'm learning from — playing right here, no redirects.</p>
    </div>
    ${
      list.length
        ? `<div class="vgrid">${list.map(videoCard).join("")}</div>`
        : `<div class="empty">${icon("play")}<h3>Videos coming soon</h3><p>I'm preparing short videos about what I'm learning. In the meantime, say hello — I always reply.</p><a class="btn btn--dark" href="/#contact">Suggest a topic ${icon("arrow-up-right")}</a></div>`
    }
    <div class="section-foot reveal">
      <a class="btn btn--dark btn--lg" href="/videos">All videos ${icon("arrow-right")}</a>
    </div>
  </div>
</section>`;
}

function visionSection(about) {
  return `
<section class="vision">
  <div class="container vision__inner reveal">
    <span class="vision__mark">${icon("quote")} </span>
    <blockquote>
      <p class="vision__quote">${esc(about.quote)}</p>
      <footer>
        <cite>Nasir Hamid</cite>
        <span>${esc(about.motto)}</span>
      </footer>
    </blockquote>
    <p class="vision__body">${esc(about.vision)}</p>
  </div>
</section>`;
}

function contactSection(profile) {
  return `
<section class="section section--ink" id="contact">
  <div class="container">
    <div class="section-head section-head--light reveal">
      <p class="eyebrow"><span class="dot"></span>Contact</p>
      <h2 class="display">Let's <span class="hl">connect</span>.</h2>
      <p class="section-head__note">Questions about something I've shared, a resource that helped you, or just want to say salam? My inbox is open.</p>
    </div>
    <div class="contact">
      <div class="contact__info reveal">
        <a class="contact__row" href="mailto:${esc(profile.email)}">
          <span class="contact__ic">${icon("mail")}</span>
          <span><em>Email</em><strong>${esc(profile.email)}</strong></span>
          ${icon("arrow-up-right", "contact__arrow")}
        </a>
        <a class="contact__row" href="tel:${esc(profile.phoneIntl)}">
          <span class="contact__ic">${icon("phone")}</span>
          <span><em>Phone</em><strong>${esc(profile.phone)}</strong></span>
          ${icon("arrow-up-right", "contact__arrow")}
        </a>
        <a class="contact__row" href="${esc(profile.github)}" target="_blank" rel="noopener">
          <span class="contact__ic">${icon("github")}</span>
          <span><em>GitHub</em><strong>nasirhamid1751-web</strong></span>
          ${icon("arrow-up-right", "contact__arrow")}
        </a>
        <div class="contact__note">
          <span class="dot"></span> ${esc(profile.availability)}
        </div>
      </div>
      <form class="cform reveal" id="contactForm" style="--d:80ms" novalidate>
        <div class="cform__row">
          <label class="field">
            <span>Your name</span>
            <input type="text" name="name" required minlength="2" maxlength="80" autocomplete="name" placeholder="Ahmad Khan">
          </label>
          <label class="field">
            <span>Email address</span>
            <input type="email" name="email" required maxlength="120" autocomplete="email" placeholder="you@example.com">
          </label>
        </div>
        <label class="field">
          <span>Subject</span>
          <input type="text" name="subject" maxlength="120" placeholder="What's this about?">
        </label>
        <label class="field">
          <span>Message</span>
          <textarea name="message" rows="5" required minlength="10" maxlength="4000" placeholder="Write your message here…"></textarea>
        </label>
        <input type="text" name="company" class="honeypot" tabindex="-1" autocomplete="off" aria-hidden="true">
        <div class="cform__foot">
          <button class="btn btn--primary btn--lg" type="submit">Send message ${icon("arrow-up-right")}</button>
          <p class="cform__status" id="formStatus" role="status" aria-live="polite"></p>
        </div>
        <p class="cform__privacy">Your details are only used to reply to you. No newsletters, no sharing.</p>
      </form>
    </div>
  </div>
</section>
<dialog class="video-modal" id="videoModal" aria-label="Video player">
  <div class="video-modal__inner">
    <button class="video-modal__close" id="videoClose" aria-label="Close video">${icon("close")}</button>
    <div class="video-modal__frame" id="videoFrame"></div>
  </div>
</dialog>`;
}

/* --------------------------------------------------------------------- pages */
function homePage({ nonce, profile, about, skills, projects, resources, videos, siteUrl }) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: profile.name,
    url: siteUrl,
    image: `${siteUrl}/images/hero-portrait-900.jpg`,
    jobTitle: "Grade 10 Student",
    email: `mailto:${profile.email}`,
    sameAs: [profile.github, profile.website].filter(Boolean),
    knowsAbout: (skills.groups || []).map((s) => s.title),
    description: profile.tagline,
  };
  return layout({
    title: "Nasir Hamid — Grade 10 Student & Self-Taught Computer Science Learner",
    description:
      "Portfolio of Nasir Hamid, a Grade 10 student building a foundation in computer science through self-study. Projects, free PDF resources, notes and videos.",
    canonical: siteUrl + "/",
    profile,
    nonce,
    active: "Home",
    jsonLd,
    body:
      hero(profile) +
      aboutSection(about, profile) +
      skillsSection(skills) +
      projectsSection(projects) +
      resourcesSection(resources) +
      videosSection(videos) +
      visionSection(about) +
      contactSection(profile),
  });
}

function pageHeader({ eyebrow, title, note, back }) {
  return `
<section class="page-head">
  <div class="container">
    ${
      back
        ? `<a class="breadcrumb" href="${back.href}">${icon("arrow-left")} ${esc(back.label)}</a>`
        : ""
    }
    <p class="eyebrow"><span class="dot"></span>${esc(eyebrow)}</p>
    <h1 class="display">${title}</h1>
    ${note ? `<p class="page-head__note">${esc(note)}</p>` : ""}
  </div>
</section>`;
}

function videoModalMarkup() {
  return `
<dialog class="video-modal" id="videoModal" aria-label="Video player">
  <div class="video-modal__inner">
    <button class="video-modal__close" id="videoClose" aria-label="Close video">${icon("close")}</button>
    <div class="video-modal__frame" id="videoFrame"></div>
  </div>
</dialog>`;
}

function projectsPage({ nonce, projects, profile, siteUrl }) {
  const list = projects.filter((p) => p.published);
  return layout({
    title: "Projects — Nasir Hamid",
    description:
      "Websites and experiments built by Nasir Hamid while learning computer science: live links, source code and what each project taught him.",
    canonical: `${siteUrl}/projects`,
    profile,
    nonce,
    active: "Projects",
    pageClass: "page",
    body:
      pageHeader({
        eyebrow: "Projects",
        title: 'Things I\'ve<br>built so <span class="hl">far</span>',
        note: "Every project here is real and reachable. Quality over quantity — I'd rather finish two things properly than start ten.",
      }) +
      `<section class="section section--paper section--tight">
        <div class="container">
          ${
            list.length
              ? `<div class="pgrid">${(() => {
                  const flags = projectFlags(list);
                  return list.map((p, i) => projectCard(p, flags[i])).join("");
                })()}</div>`
              : `<div class="empty">${icon("code")}<h3>First project incoming</h3><p>I'm building something worth showing. Check back soon.</p></div>`
          }
        </div>
      </section>`,
  });
}

function projectPage({ nonce, project, profile, siteUrl, related }) {
  const tech = Array.isArray(project.tech) ? project.tech : [];
  return layout({
    title: `${project.title} — Nasir Hamid`,
    description: project.summary || `A project by Nasir Hamid: ${project.title}`,
    canonical: `${siteUrl}/projects/${project.slug}`,
    ogImage: project.thumb && project.thumb.startsWith("/images") ? project.thumb : "/images/og-image.jpg",
    profile,
    nonce,
    active: "Projects",
    pageClass: "page",
    body:
      pageHeader({
        eyebrow: "Project",
        title: esc(project.title),
        note: project.summary,
        back: { href: "/projects", label: "All projects" },
      }) +
      `<section class="section section--paper section--tight">
        <div class="container">
          <div class="detail">
            <div class="detail__main">
              ${
                project.thumb
                  ? `<figure class="detail__hero"><img src="${esc(project.thumb)}" alt="Preview of ${esc(project.title)}" width="1200" height="750" loading="eager" decoding="async"></figure>`
                  : ""
              }
              <div class="prose">${textParagraphs(project.description || project.summary)}</div>
              ${
                tech.length
                  ? `<h2 class="h3">Built with</h2><ul class="chips">${tech.map((t) => `<li>${esc(t)}</li>`).join("")}</ul>`
                  : ""
              }
            </div>
            <aside class="detail__side">
              <div class="detail__card">
                <h3>Project links</h3>
                ${
                  project.live_url
                    ? `<a class="btn btn--dark" href="${esc(project.live_url)}" target="_blank" rel="noopener">Live project ${icon("arrow-up-right")}</a>`
                    : ""
                }
                ${
                  project.repo_url
                    ? `<a class="btn btn--ghost" href="${esc(project.repo_url)}" target="_blank" rel="noopener">${icon("github")} Source code</a>`
                    : ""
                }
                <p class="detail__meta">${icon("calendar")} ${dateLabel(project.created_at)}</p>
              </div>
              ${
                related?.length
                  ? `<div class="detail__card"><h3>Next project</h3>${related
                      .map(
                        (p) =>
                          `<a class="link-arrow" href="/projects/${esc(p.slug)}">${esc(p.title)} ${icon("arrow-right")}</a>`
                      )
                      .join("")}</div>`
                  : ""
              }
              <a class="btn btn--ghost" href="/#contact">${icon("mail")} Ask me about it</a>
            </aside>
          </div>
        </div>
      </section>`,
  });
}

function resourcesPage({ nonce, resources, profile, siteUrl }) {
  const list = resources.filter((r) => r.published);
  const cats = ["All", ...new Set(list.map((r) => r.category))];
  return layout({
    title: "Free Resources & Downloads — Nasir Hamid",
    description:
      "Download free PDF documents, study notes, guides and presentations shared by Nasir Hamid. Everything is available instantly, no sign-up required.",
    canonical: `${siteUrl}/resources`,
    profile,
    nonce,
    active: "Resources",
    pageClass: "page",
    body:
      pageHeader({
        eyebrow: "Resources",
        title: 'Notes &amp; files<br>worth <span class="hl">sharing</span>',
        note: "Documents, study notes and guides I'm allowed to pass on. Free to download, no account needed.",
      }) +
      `<section class="section section--ink section--tight">
        <div class="container">
          ${
            list.length
              ? `<div class="filter" role="tablist" aria-label="Filter resources by category">${cats
                  .map(
                    (c, i) =>
                      `<button class="filter__btn${i === 0 ? " is-active" : ""}" role="tab" aria-selected="${i === 0}" data-filter="${esc(c)}">${esc(c)}</button>`
                  )
                  .join("")}</div>
                <div class="rgrid" id="resourceGrid">${list.map(resourceCard).join("")}${promoCard()}</div>
                <p class="rgrid__empty" id="resourceEmpty" hidden>Nothing published in this category yet.</p>`
              : `<div class="empty empty--dark">${icon("file-text")}<h3>The library is being filled</h3><p>Study notes and guides are on the way. Check back soon.</p></div>`
          }
          <div class="note-box">
            <span class="note-box__icon">${icon("shield")}</span>
            <p><strong>About these files:</strong> only material I created or am allowed to share is published here. Every upload is validated by the server before it goes live.</p>
          </div>
        </div>
      </section>`,
  });
}

function resourcePage({ nonce, resource, profile, siteUrl, related }) {
  return layout({
    title: `${resource.title} — Free PDF download | Nasir Hamid`,
    description: resource.description || `Download ${resource.title} (PDF) from Nasir Hamid's resource library.`,
    canonical: `${siteUrl}/resources/${resource.slug}`,
    profile,
    nonce,
    active: "Resources",
    pageClass: "page",
    body:
      pageHeader({
        eyebrow: resource.category,
        title: esc(resource.title),
        note: resource.description,
        back: { href: "/resources", label: "Resource library" },
      }) +
      `<section class="section section--ink section--tight">
        <div class="container">
          <div class="detail">
            <div class="detail__main">
              <div class="rpreview">
                <div class="rpreview__bar">
                  <span></span><span></span><span></span>
                  <em>${esc(resource.file_name)}</em>
                </div>
                <div class="rpreview__body">
                  ${
                    resource.thumb
                      ? `<img src="${esc(resource.thumb)}" alt="${esc(resource.title)} preview" loading="lazy" decoding="async">`
                      : `<div class="rpreview__pdf">
                          <span class="rpreview__pdf-ext">PDF</span>
                          <span class="rpreview__pdf-title">${esc(resource.title)}</span>
                          <span class="rpreview__pdf-meta">${fileSize(resource.file_size)} · ${esc(resource.category)}</span>
                        </div>`
                  }
                </div>
              </div>
              <p class="rpreview__hint">${icon("eye")} Opens in your browser after download — no sign-up, no email required.</p>
            </div>
            <aside class="detail__side">
              <div class="detail__card">
                <h3>Download details</h3>
                <dl class="dlist">
                  <div><dt>File type</dt><dd>PDF</dd></div>
                  <div><dt>Size</dt><dd>${fileSize(resource.file_size)}</dd></div>
                  <div><dt>Published</dt><dd>${dateLabel(resource.created_at)}</dd></div>
                  <div><dt>Downloads</dt><dd>${resource.downloads}</dd></div>
                  <div><dt>Category</dt><dd>${esc(resource.category)}</dd></div>
                </dl>
                <a class="btn btn--primary btn--lg" href="/download/${esc(resource.slug)}">${icon("download")} Download PDF</a>
                <p class="detail__meta">${icon("shield")} Scanned and validated on upload</p>
              </div>
              ${
                related?.length
                  ? `<div class="detail__card"><h3>More resources</h3>${related
                      .map(
                        (r) =>
                          `<a class="link-arrow" href="/resources/${esc(r.slug)}">${esc(r.title)} ${icon("arrow-right")}</a>`
                      )
                      .join("")}</div>`
                  : ""
              }
            </aside>
          </div>
        </div>
      </section>`,
  });
}

function videosPage({ nonce, videos, profile, siteUrl }) {
  const list = videos.filter((v) => v.published);
  const cats = [...new Set(list.map((v) => v.category))];
  return layout({
    title: "Videos — Nasir Hamid",
    description:
      "Videos published and recommended by Nasir Hamid while learning computer science — watch in-page, by category or playlist.",
    canonical: `${siteUrl}/videos`,
    profile,
    nonce,
    active: "Videos",
    pageClass: "page",
    body:
      pageHeader({
        eyebrow: "Videos",
        title: 'Watch,<br>then <span class="hl">build</span>',
        note: "Talks, lectures and clips I'm publishing or learning from. Press play — everything loads here on the page.",
      }) +
      `<section class="section section--paper section--tight">
        <div class="container">
          ${
            list.length
              ? (cats.length > 1
                  ? `<div class="filter filter--dark-text" role="tablist" aria-label="Filter videos by category">${["All", ...cats]
                      .map(
                        (c, i) =>
                          `<button class="filter__btn${i === 0 ? " is-active" : ""}" role="tab" aria-selected="${i === 0}" data-filter="${esc(c)}">${esc(c)}</button>`
                      )
                      .join("")}</div>`
                  : "") +
                `<div class="vgrid" id="videoGrid">${list.map(videoCard).join("")}</div>`
              : `<div class="empty">${icon("play")}<h3>Videos coming soon</h3><p>I'm preparing short videos about what I'm learning. In the meantime, say hello — I always reply.</p><a class="btn btn--dark" href="/#contact">Suggest a topic ${icon("arrow-up-right")}</a></div>`
          }
        </div>
      </section>` +
      videoModalMarkup(),
  });
}

function videoPage({ nonce, video, profile, siteUrl, related }) {
  const embed = video.youtube_id
    ? `https://www.youtube-nocookie.com/embed/${video.youtube_id}?rel=0`
    : null;
  return layout({
    title: `${video.title} — Nasir Hamid`,
    description: video.description || `Watch ${video.title}.`,
    canonical: `${siteUrl}/videos/${video.slug}`,
    profile,
    nonce,
    active: "Videos",
    pageClass: "page",
    body:
      pageHeader({
        eyebrow: video.category,
        title: esc(video.title),
        note: video.description,
        back: { href: "/videos", label: "All videos" },
      }) +
      `<section class="section section--paper section--tight">
        <div class="container">
          <div class="detail">
            <div class="detail__main">
              ${
                embed
                  ? `<div class="vframe" id="videoFrameInline">
                      <img src="${esc(video.thumb || "/images/og-image.jpg")}" alt="${esc(video.title)} thumbnail" width="1280" height="720">
                      <button class="vframe__play" data-video="${esc(video.youtube_id)}" data-title="${esc(video.title)}" aria-label="Play ${esc(video.title)}">${icon("play")}</button>
                      ${video.duration ? `<span class="vframe__dur">${esc(video.duration)}</span>` : ""}
                    </div>`
                  : `<div class="note-box note-box--light">${icon("external")}<p>This video is hosted externally.</p></div>`
              }
              <div class="prose">${textParagraphs(video.description)}</div>
            </div>
            <aside class="detail__side">
              <div class="detail__card">
                <h3>Video details</h3>
                <dl class="dlist">
                  <div><dt>Category</dt><dd>${esc(video.category)}</dd></div>
                  ${video.duration ? `<div><dt>Length</dt><dd>${esc(video.duration)}</dd></div>` : ""}
                  <div><dt>Added</dt><dd>${dateLabel(video.created_at)}</dd></div>
                </dl>
                ${
                  video.external_url
                    ? `<a class="btn btn--ghost" href="${esc(video.external_url)}" target="_blank" rel="noopener">Open externally ${icon("arrow-up-right")}</a>`
                    : ""
                }
                ${
                  video.youtube_id
                    ? `<a class="btn btn--ghost" href="https://www.youtube.com/watch?v=${esc(video.youtube_id)}" target="_blank" rel="noopener">Watch on YouTube ${icon("external")}</a>`
                    : ""
                }
              </div>
              ${
                related?.length
                  ? `<div class="detail__card"><h3>More videos</h3>${related
                      .map(
                        (v) =>
                          `<a class="link-arrow" href="/videos/${esc(v.slug)}">${esc(v.title)} ${icon("arrow-right")}</a>`
                      )
                      .join("")}</div>`
                  : ""
              }
            </aside>
          </div>
        </div>
      </section>` +
      videoModalMarkup(),
  });
}

function notFoundPage({ nonce, profile, siteUrl }) {
  return layout({
    title: "Page not found — Nasir Hamid",
    description: "That page doesn't exist. Head back to the homepage.",
    canonical: `${siteUrl}/404`,
    profile,
    nonce,
    robots: "noindex,follow",
    pageClass: "page",
    body: `<section class="section section--ink section--tight">
      <div class="container notfound">
        <p class="eyebrow"><span class="dot"></span>404</p>
        <h1 class="display">Dead <span class="hl">end</span>.</h1>
        <p class="page-head__note">The page you're looking for moved or never existed. Everything else is one click away.</p>
        <div class="hero__actions">
          <a class="btn btn--primary btn--lg" href="/">Back home ${icon("arrow-right")}</a>
          <a class="btn btn--ghost btn--lg" href="/resources">Resource library</a>
        </div>
      </div>
    </section>`,
  });
}

module.exports = {
  icon,
  esc,
  fileSize,
  dateLabel,
  homePage,
  projectsPage,
  projectPage,
  resourcesPage,
  resourcePage,
  videosPage,
  videoPage,
  notFoundPage,
};
