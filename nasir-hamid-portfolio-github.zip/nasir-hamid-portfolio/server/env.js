/**
 * Tiny .env loader (no dependency).
 *
 * Reads KEY=value pairs from a `.env` file next to the project root and adds
 * them to process.env, without ever overriding variables that the hosting
 * environment already set (so real platform config always wins).
 *
 * Supported syntax: comments (#), blank lines, optional `export ` prefix,
 * single/double quotes around the value, and `\n` escapes inside quotes.
 */
const fs = require("fs");
const path = require("path");

function loadEnvFile(file = path.join(__dirname, "..", ".env")) {
  let raw;
  try {
    raw = fs.readFileSync(file, "utf8");
  } catch {
    return {}; // no .env present — normal in production
  }

  const loaded = {};
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;

    const match = /^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/.exec(trimmed);
    if (!match) continue;

    const key = match[1];
    let value = match[2];

    if (
      (value.startsWith('"') && value.endsWith('"') && value.length > 1) ||
      (value.startsWith("'") && value.endsWith("'") && value.length > 1)
    ) {
      const quote = value[0];
      value = value.slice(1, -1);
      if (quote === '"') value = value.replace(/\\n/g, "\n").replace(/\\"/g, '"');
    } else {
      const hash = value.indexOf(" #"); // trailing comment
      if (hash !== -1) value = value.slice(0, hash);
      value = value.trim();
    }

    if (process.env[key] === undefined) {
      process.env[key] = value;
      loaded[key] = value;
    }
  }

  return loaded;
}

module.exports = { loadEnvFile };
