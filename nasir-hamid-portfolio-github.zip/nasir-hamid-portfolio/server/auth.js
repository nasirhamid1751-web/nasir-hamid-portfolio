/**
 * Authentication: scrypt password hashing + database-backed sessions in an
 * HttpOnly cookie. No external auth service required.
 */
const crypto = require("crypto");
const { db } = require("./db");

const SESSION_COOKIE = "nh_sid";
const SESSION_DAYS = 7;
const MAX_ATTEMPTS = 8;
const WINDOW_MS = 15 * 60 * 1000;

/* ------------------------------------------------------------------ password */
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const key = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 }).toString("hex");
  return `scrypt$${salt}$${key}`;
}

function verifyPassword(password, stored) {
  try {
    const [scheme, salt, key] = String(stored).split("$");
    if (scheme !== "scrypt" || !salt || !key) return false;
    const candidate = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
    const expected = Buffer.from(key, "hex");
    return candidate.length === expected.length && crypto.timingSafeEqual(candidate, expected);
  } catch {
    return false;
  }
}

/* -------------------------------------------------------------- login limiter */
const attempts = new Map();
function tooManyAttempts(ip) {
  const rec = attempts.get(ip);
  if (!rec) return false;
  if (Date.now() - rec.first > WINDOW_MS) {
    attempts.delete(ip);
    return false;
  }
  return rec.count >= MAX_ATTEMPTS;
}
function recordAttempt(ip) {
  const rec = attempts.get(ip);
  if (!rec || Date.now() - rec.first > WINDOW_MS) attempts.set(ip, { first: Date.now(), count: 1 });
  else rec.count += 1;
}
function clearAttempts(ip) {
  attempts.delete(ip);
}

/* ------------------------------------------------------------------- sessions */
const sha = (v) => crypto.createHash("sha256").update(v).digest("hex");

function createSession(res, adminId) {
  const token = crypto.randomBytes(32).toString("hex");
  const expires = Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000;
  db.prepare("INSERT INTO sessions (token_hash, admin_id, expires_at) VALUES (?, ?, ?)").run(
    sha(token),
    adminId,
    expires
  );
  db.prepare("DELETE FROM sessions WHERE expires_at < ?").run(Date.now());
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production" && process.env.INSECURE_COOKIES !== "1",
    maxAge: SESSION_DAYS * 24 * 60 * 60 * 1000,
    path: "/",
  });
  return token;
}

function destroySession(req, res) {
  const token = req.cookies?.[SESSION_COOKIE];
  if (token) db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(sha(token));
  res.clearCookie(SESSION_COOKIE, { path: "/" });
}

function currentAdmin(req) {
  const token = req.cookies?.[SESSION_COOKIE];
  if (!token) return null;
  const row = db
    .prepare(
      `SELECT a.id, a.email, s.expires_at FROM sessions s
       JOIN admins a ON a.id = s.admin_id WHERE s.token_hash = ?`
    )
    .get(sha(token));
  if (!row) return null;
  if (row.expires_at < Date.now()) {
    db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(sha(token));
    return null;
  }
  return { id: row.id, email: row.email };
}

/* ------------------------------------------------------------------ middleware */
function requireAuth(req, res, next) {
  const admin = currentAdmin(req);
  if (!admin) return res.status(401).json({ error: "Not authenticated" });
  req.admin = admin;
  next();
}

/**
 * CSRF hardening for the JSON API: the session cookie is SameSite=Strict, and
 * state-changing requests must also carry the custom header set by admin.js and
 * come from the same origin. A cross-site form/script cannot set that header.
 */
function requireSameOrigin(req, res, next) {
  if (!["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) return next();
  if (req.get("x-requested-with") !== "fetch") {
    return res.status(403).json({ error: "Missing anti-CSRF header" });
  }
  const origin = req.get("origin");
  if (origin) {
    const host = req.get("host");
    let originHost = null;
    try {
      originHost = new URL(origin).host;
    } catch {}
    if (originHost !== host) return res.status(403).json({ error: "Cross-origin request blocked" });
  }
  next();
}

/* --------------------------------------------------------- first-run admin user */
function ensureAdmin() {
  const count = db.prepare("SELECT COUNT(*) c FROM admins").get().c;
  if (count > 0) return;
  const email = (process.env.ADMIN_EMAIL || "nasirhamid1751@gmail.com").toLowerCase();
  const password = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString("base64url");
  db.prepare("INSERT INTO admins (email, pass_hash) VALUES (?, ?)").run(
    email,
    hashPassword(password)
  );
  if (!process.env.ADMIN_PASSWORD) {
    const fs = require("fs");
    const path = require("path");
    const { DATA_DIR } = require("./db");
    const file = path.join(DATA_DIR, "ADMIN-CREDENTIALS.txt");
    fs.writeFileSync(
      file,
      `Portfolio admin account created ${new Date().toISOString()}\n\n` +
        `Login URL : /admin\nEmail     : ${email}\nPassword  : ${password}\n\n` +
        `Change this password after your first login, then delete this file.\n`,
      { mode: 0o600 }
    );
    console.log("\n──────────────────────────────────────────────");
    console.log(" Admin account created");
    console.log(`   email:    ${email}`);
    console.log(`   password: ${password}`);
    console.log(`   saved to: ${file}`);
    console.log("──────────────────────────────────────────────\n");
  }
}

module.exports = {
  SESSION_COOKIE,
  hashPassword,
  verifyPassword,
  tooManyAttempts,
  recordAttempt,
  clearAttempts,
  createSession,
  destroySession,
  currentAdmin,
  requireAuth,
  requireSameOrigin,
  ensureAdmin,
};
