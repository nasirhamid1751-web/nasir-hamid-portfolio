/**
 * All editorial content for the site.
 * Every fact here comes from Nasir's existing portfolio
 * (https://nasirhamid1751-web.github.io/Nasir-Portfolio/) — wording refined only.
 * After first boot this content lives in the database and is editable from /admin.
 */

const profile = {
  name: "Nasir Hamid",
  role: "Grade 10 Student · Self-Taught Computer Science Learner",
  eyebrow: "Grade 10 · Self-taught · Curious",
  headlineLine1: "Nasir",
  headlineLine2: "Hamid",
  // kept short — it sits under the name in the hero
  tagline:
    "A Grade 10 student building a foundation in computer science — one late night of self-study at a time.",
  intro:
    "I'm driven by curiosity, discipline, and a growing love for how software gets made. My goal is simple: keep learning every day, get genuinely good at technology, and build things that are useful to other people.",
  status: "Preparing for Grade 10 examinations",
  email: "nasirhamid1751@gmail.com",
  phone: "0332-6162675",
  phoneIntl: "+923326162675",
  github: "https://github.com/nasirhamid1751-web",
  website: "https://nasirhamid1751-web.github.io/Nasir-Portfolio/",
  availability: "Open to learning opportunities, questions and collaboration",
  // Slug of the resource that the hero "Download CV" button points to
  cvSlug: "nasir-hamid-cv",
  facts: [
    { label: "Studying", value: "Grade 10" },
    { label: "Focus", value: "Computer Science" },
    { label: "Based in", value: "Pakistan" },
  ],
};

const about = {
  lead:
    "I'm a dedicated and enthusiastic student with a strong academic foundation, a growing passion for computer science, and a simple plan: learn something useful every single day.",
  paragraphs: [
    "My educational journey began at Government Primary School, Star Jummat Kharmana, where I built a strong academic foundation and consistently achieved excellent results. I then continued at Government High School, Dogar — a period that pushed me toward deeper learning, critical thinking and personal growth.",
    "My passion for computer science carried me beyond the classroom. I spend my free time exploring technology, understanding how computers really work, and steadily expanding what I know. There is no shortcut in this field, so I focus on the fundamentals and on finishing what I start.",
    "Right now I'm preparing for my Grade 10 examinations and aiming for outstanding results — while keeping my technical learning moving alongside it. This website is part of that work: a place to document what I build, share what I learn, and keep myself accountable.",
  ],
  interests: [
    "Improving my English language skills",
    "Exploring computer science and technology",
    "Educational and informative content on YouTube",
    "New ideas, knowledge and innovations",
    "Learning in public — sharing what I study",
  ],
  timeline: [
    {
      step: "01",
      tag: "Foundation",
      title: "Government Primary School, Star Jummat Kharmana",
      desc: "Where it all began. A strong academic foundation and consistently excellent results throughout primary education.",
    },
    {
      step: "02",
      tag: "Growth",
      title: "Government High School, Dogar",
      desc: "Secondary school marked a turning point — a deeper interest in learning, critical thinking and personal growth.",
    },
    {
      step: "03",
      tag: "Exploration",
      title: "Independent Study — Computer Science",
      desc: "A growing passion for CS led to learning beyond the classroom: exploring technology and how computers really work.",
    },
    {
      step: "04",
      tag: "Launch",
      title: "Grade 10 — In Progress",
      desc: "Preparing for Grade 10 examinations, aiming for outstanding results and a strong launch into the future.",
    },
  ],
  vision:
    "I believe that continuous learning, hard work and determination are the keys to success. I'm committed to developing my knowledge and skills every day so I can contribute positively to society and reach my future goals.",
  quote: "Education is the foundation of success, and learning never stops.",
  motto: "Code. Build. Repeat. — one step at a time.",
};

const skills = {
  intro:
    "No inflated bars and no invented expertise — just an honest picture of where I am right now and what I practise every week.",
  groups: [
    {
      icon: "cpu",
      title: "Computer Science Fundamentals",
      level: "Exploring",
      desc: "How computers actually work: hardware basics, operating systems and the ideas that sit underneath software.",
    },
    {
      icon: "code",
      title: "Web Foundations — HTML & CSS",
      level: "Foundational",
      desc: "Structuring and styling real pages with semantic HTML, modern layout and responsive design.",
    },
    {
      icon: "js",
      title: "JavaScript Basics",
      level: "Learning",
      desc: "Variables, functions and simple DOM behaviour — building small interactions and understanding them properly.",
    },
    {
      icon: "book",
      title: "Self-Directed Learning",
      level: "Daily practice",
      desc: "Planning my own study, finding reliable sources and finishing what I start — the skill that makes the rest possible.",
    },
    {
      icon: "brain",
      title: "Critical Thinking",
      level: "Developing",
      desc: "Breaking problems into smaller pieces, asking better questions and checking answers instead of guessing.",
    },
    {
      icon: "lang",
      title: "English Communication",
      level: "Improving",
      desc: "Reading, writing and speaking with clarity — actively working on this every day, in study and on this site.",
    },
  ],
};

const seo = {
  // Leave empty to use the domain the site is served from; set it once you have a custom domain.
  siteUrl: "",
  title: "Nasir Hamid — Grade 10 Student & Self-Taught Computer Science Learner",
  description:
    "Portfolio of Nasir Hamid, a Grade 10 student in Pakistan building a foundation in computer science through self-study. Projects, learning notes, PDF resources and videos.",
  keywords:
    "Nasir Hamid, student portfolio, computer science, self-taught developer, Pakistan, learning resources, Grade 10",
};

module.exports = { profile, about, skills, seo };
