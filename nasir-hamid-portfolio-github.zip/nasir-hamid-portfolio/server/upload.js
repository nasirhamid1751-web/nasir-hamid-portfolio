/**
 * File upload handling: disk storage with random names, type + size validation,
 * and magic-byte checking so a renamed file cannot sneak in.
 */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const multer = require("multer");
const { UPLOAD_DIR } = require("./db");

const PDF_DIR = path.join(UPLOAD_DIR, "pdf");
const IMG_DIR = path.join(UPLOAD_DIR, "images");
fs.mkdirSync(PDF_DIR, { recursive: true });
fs.mkdirSync(IMG_DIR, { recursive: true });

const MAX_PDF = 25 * 1024 * 1024; // 25 MB
const MAX_IMG = 5 * 1024 * 1024; // 5 MB
const IMAGE_TYPES = { "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp" };

const storage = multer.diskStorage({
  destination(req, file, cb) {
    cb(null, file.fieldname === "file" ? PDF_DIR : IMG_DIR);
  },
  filename(req, file, cb) {
    const ext = path.extname(file.originalname || "").toLowerCase().slice(0, 6);
    cb(null, `${Date.now().toString(36)}-${crypto.randomBytes(8).toString("hex")}${ext}`);
  },
});

const uploader = multer({
  storage,
  limits: { fileSize: MAX_PDF, files: 4, fields: 30 },
  fileFilter(req, file, cb) {
    if (file.fieldname === "file") {
      if (file.mimetype !== "application/pdf" && !/\.pdf$/i.test(file.originalname || "")) {
        return cb(new Error("Only PDF files are accepted for resource uploads."));
      }
      return cb(null, true);
    }
    if (!IMAGE_TYPES[file.mimetype]) {
      return cb(new Error("Thumbnails must be JPG, PNG or WebP images."));
    }
    cb(null, true);
  },
});

/** Reads the first bytes of a file to confirm it really is what it claims. */
function sniff(filePath) {
  const buf = Buffer.alloc(12);
  const fd = fs.openSync(filePath, "r");
  try {
    fs.readSync(fd, buf, 0, 12, 0);
  } finally {
    fs.closeSync(fd);
  }
  if (buf.subarray(0, 5).toString("latin1") === "%PDF-") return "pdf";
  if (buf[0] === 0xff && buf[1] === 0xd8) return "jpg";
  if (buf.subarray(0, 8).toString("hex") === "89504e470d0a1a0a") return "png";
  if (buf.subarray(0, 4).toString("latin1") === "RIFF" && buf.subarray(8, 12).toString("latin1") === "WEBP")
    return "webp";
  return null;
}

/** Removes a file if validation failed. */
const cleanup = (files = {}) => {
  for (const list of Object.values(files)) {
    for (const f of Array.isArray(list) ? list : [list]) {
      if (f?.path) fs.promises.unlink(f.path).catch(() => {});
    }
  }
};

/**
 * Validates every uploaded file after multer has written it.
 * Returns { error } or { pdf, thumb } describing safe stored paths.
 */
function validateFiles(files = {}, { requirePdf = false } = {}) {
  const pdf = files.file?.[0];
  const thumb = files.thumb?.[0];

  if (requirePdf && !pdf) return { error: "A PDF file is required." };

  if (pdf) {
    if (pdf.size > MAX_PDF) return { error: "PDF is larger than the 25 MB limit." };
    if (sniff(pdf.path) !== "pdf") return { error: "That file is not a valid PDF." };
  }
  if (thumb) {
    if (thumb.size > MAX_IMG) return { error: "Thumbnail is larger than the 5 MB limit." };
    if (!sniff(thumb.path)) return { error: "Thumbnail must be a real JPG, PNG or WebP image." };
  }

  return {
    pdf: pdf ? { stored: path.join("uploads", "pdf", pdf.filename), size: pdf.size, name: pdf.originalname } : null,
    thumb: thumb ? { url: `/media/images/${thumb.filename}` } : null,
  };
}

/* ---------------------------------------------- remote thumbnail self-hosting */
const YT_THUMB_HOST = "https://i.ytimg.com/vi/";

/** Downloads an image into uploads/images so no third-party request is needed. */
async function saveRemoteImage(url, { minBytes = 1 } = {}) {
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length < minBytes || buf.length > MAX_IMG) return null;
    if (buf[0] !== 0xff || buf[1] !== 0xd8) return null; // JPEG only
    const name = `${Date.now().toString(36)}-${crypto.randomBytes(8).toString("hex")}.jpg`;
    fs.writeFileSync(path.join(IMG_DIR, name), buf);
    return `/media/images/${name}`;
  } catch {
    return null;
  }
}

/**
 * Pulls a YouTube thumbnail into local storage (privacy + no broken images if the
 * video is later made private). Falls back to the always-available hqdefault.
 */
async function fetchYouTubeThumb(youtubeId) {
  if (!youtubeId) return null;
  const hd = await saveRemoteImage(`${YT_THUMB_HOST}${encodeURIComponent(youtubeId)}/maxresdefault.jpg`, {
    minBytes: 15 * 1024, // the 120x90 "no preview" placeholder is tiny
  });
  if (hd) return hd;
  return saveRemoteImage(`${YT_THUMB_HOST}${encodeURIComponent(youtubeId)}/hqdefault.jpg`);
}

/** Deletes a stored upload (never touches files outside the uploads folder). */
function removeStored(storedPath) {
  if (!storedPath || !storedPath.startsWith("uploads")) return;
  const abs = path.join(UPLOAD_DIR, storedPath.replace(/^uploads[\\/]/, ""));
  if (!abs.startsWith(UPLOAD_DIR)) return;
  fs.promises.unlink(abs).catch(() => {});
}

function removeThumb(url) {
  if (!url || !url.startsWith("/media/images/")) return;
  const abs = path.join(IMG_DIR, path.basename(url));
  if (!abs.startsWith(IMG_DIR)) return;
  fs.promises.unlink(abs).catch(() => {});
}

module.exports = {
  uploader,
  uploadFields: uploader.fields([
    { name: "file", maxCount: 1 },
    { name: "thumb", maxCount: 1 },
  ]),
  validateFiles,
  cleanup,
  removeStored,
  removeThumb,
  fetchYouTubeThumb,
  MAX_PDF,
  MAX_IMG,
};
